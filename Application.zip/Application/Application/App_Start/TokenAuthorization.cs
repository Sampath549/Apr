﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;

namespace Application.App_Start
{
    public class TokenAuthorization
    {
        public string GenerateToken()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            string message = string.Join(":", new string[] { Convert.ToString(_SessionUserDetails.Email), GenrateRandomString(4) });
            string securehash = CalculateSecureHash(message);
            string token = string.Join(";", message, securehash);
            return (token);
        }
        public string CalculateSecureHash(string msg)
        {
            string key = GlobalVariables.Shared.SecureTokenKey;
            var encoding = new System.Text.ASCIIEncoding();
            byte[] keyByte = encoding.GetBytes(key);
            byte[] messageBytes = encoding.GetBytes(msg);
            string securehash = null;
            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                byte[] hashmessage = hmacsha256.ComputeHash(messageBytes);
                securehash = Convert.ToBase64String(hashmessage);
            }
            return (securehash);
        }
        public static string GenrateRandomString(byte n)
        {
            byte[] randombytes = new byte[n];
            RNGCryptoServiceProvider provider = new RNGCryptoServiceProvider();
            provider.GetBytes(randombytes);
            return (Convert.ToBase64String(randombytes));
        }
    }
}