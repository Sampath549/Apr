﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelDAL : DataAccessComponent
    {
        public SE_Users AuthenticatedUser(string Email, string Password)
        {
            SE_Users _Result = new SE_Users();
            DataTable dtUserDetails = new DataTable();
            using (SqlConnection con = new SqlConnection(DB_ADOConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_Get_AuthenticatedUser", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@EmailId", Email);
                    da.SelectCommand.Parameters.AddWithValue("@Password", Password);

                    da.Fill(dtUserDetails);

                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["UserId"].ToString()))
                    {
                        _Result.Status = Convert.ToInt32(dtUserDetails.Rows[0]["Status"]);
                        _Result.UserId = Convert.ToInt32(dtUserDetails.Rows[0]["UserId"]);
                        _Result.FirstName = Convert.ToString(dtUserDetails.Rows[0]["FirstName"]);
                        _Result.LastName = Convert.ToString(dtUserDetails.Rows[0]["LastName"]);
                        _Result.FullName = Convert.ToString(dtUserDetails.Rows[0]["FullName"]);
                        _Result.Email = Convert.ToString(dtUserDetails.Rows[0]["Email"]);
                        _Result.Mobile = Convert.ToString(dtUserDetails.Rows[0]["Mobile"]);
                        _Result.RoleId = Convert.ToInt32(dtUserDetails.Rows[0]["RoleId"]);
                        _Result.RoleCode = Convert.ToString(dtUserDetails.Rows[0]["RoleCode"]);
                        _Result.IsFirstTimeLogin = Convert.ToBoolean(dtUserDetails.Rows[0]["IsFirstTimeLogin"]);
                        if (dtUserDetails.Rows[0]["Photo"] != DBNull.Value)
                            _Result.ProfilePic = Convert.ToString(dtUserDetails.Rows[0]["Photo"]);
                    }
                }
            }
            return _Result;
        }

        public string GetMenus(string RoleCode)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_MenuListByRole", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@RoleCode", RoleCode);

                        da.Fill(_Result);
                    }
                }
                return JsonMenusList(_Result);
            }
            catch (WebException ex)
            { throw ex; }
        }
        public string JsonMenusList(DataSet _Result)
        {
            try
            {
                var _Menus = new StringBuilder();
                if (_Result.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < _Result.Tables[0].Rows.Count; i++)
                    {
                        if (!Convert.ToBoolean(_Result.Tables[0].Rows[i]["HavingChild"]))
                            _Menus.Append("<li class='nav-item' id='menu" + i + "'><a href = '/" + _Result.Tables[0].Rows[i]["Controller"].ToString() + "/" + _Result.Tables[0].Rows[i]["Action"].ToString() + "'><i class='" + _Result.Tables[0].Rows[i]["Icon"].ToString() + "'></i><span data-i18n='' class='menu-title'>" + _Result.Tables[0].Rows[i]["Header"].ToString() + "</span></a></li>");
                        else
                        {
                            _Menus.Append("<li class='has-sub nav-item' id='menu" + i + "'>");
                            _Menus.Append("<a href = '#'><i class='" + _Result.Tables[0].Rows[i]["Icon"].ToString() + "'></i><span data-i18n='' class='menu-title'>" + _Result.Tables[0].Rows[i]["Header"].ToString() + "</span></a>");
                            _Menus.Append("<ul class='menu-content'>");
                            for (int j = 0; j < _Result.Tables[1].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(_Result.Tables[0].Rows[i]["ParentId"]) == Convert.ToInt32(_Result.Tables[1].Rows[j]["ParentId"]))
                                    _Menus.Append("<li><a class='menu-item' href='/" + _Result.Tables[1].Rows[j]["Controller"].ToString() + "/" + _Result.Tables[1].Rows[j]["Action"].ToString() + "'>" + _Result.Tables[1].Rows[j]["Header"].ToString() + "</a></li>");
                            }
                            _Menus.Append("</ul>");
                            _Menus.Append("</li>");


                            //< li class="active">
                            //    <a href = "dashboard1.html" class="menu-item">Dashboard1</a>
                            //</li>
                            //<li>
                            //    <a href = "dashboard2.html" class="menu-item">Dashboard2</a>
                            //</li>

                            //_Menus.Append("<li id='menu" + i + "'>");
                            //_Menus.Append("<a id='submenu" + i + "' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'><i class='" + _Result.Tables[0].Rows[i]["Icon"].ToString() + "'></i> " + _Result.Tables[0].Rows[i]["Header"].ToString() + "</a>");
                            //_Menus.Append("<ul class='dropdown-menu' aria-labelledby='submenu" + i + "'>");
                            //for (int j = 0; j < _Result.Tables[1].Rows.Count; j++)
                            //{
                            //    if (Convert.ToInt32(_Result.Tables[0].Rows[i]["ParentId"]) == Convert.ToInt32(_Result.Tables[1].Rows[j]["ParentId"]))
                            //        _Menus.Append("<li><a href='/" + _Result.Tables[1].Rows[j]["Controller"].ToString() + "/" + _Result.Tables[1].Rows[j]["Action"].ToString() + "'>" + _Result.Tables[1].Rows[j]["Header"].ToString() + "</a></li>");
                            //}
                            //_Menus.Append("</ul>");
                            //_Menus.Append("</li>");
                        }
                    }
                }
                return _Menus.ToString();
            }
            catch (WebException ex)
            { throw ex; }
        }
    }
}