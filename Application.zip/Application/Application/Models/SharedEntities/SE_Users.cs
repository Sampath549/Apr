﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Users
    {
        public int Status { get; set; }
        public int UserId { get; set; }
        public string PersonalKey { get; set; }
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string SaltKey { get; set; }
        public string Mobile { get; set; }
        public string RoleCode { get; set; }
        public int RoleId { get; set; }
        public string ProfilePic { get; set; }
        public bool IsFirstTimeLogin { get; set; }
        public string GRecaptchaResponse { get; set; }
        public string RedirectUrl { get; set; }
    }
}