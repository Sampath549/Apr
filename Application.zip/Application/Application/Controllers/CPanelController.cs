﻿using Application.App_Start;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class CPanelController : Controller
    {
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult LoginAuthentication(string _User, string _Password, string _ReCaptcha)
        {
            try
            {
                return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}