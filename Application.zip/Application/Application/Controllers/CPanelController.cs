﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class CPanelController : Controller
    {
        SE_Users Users = new SE_Users();

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult LoginAuthentication(string _User, string _Password, string _ReCaptcha)
        {
            try
            {
                //Checking ReCaptcha Required or Not
                if (GlobalVariables.Shared.ReCaptcha)
                {
                    bool chk = isCaptchaValid(_ReCaptcha);
                    if (!chk)
                        return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                }

                //Server-Side Validations
                if (_User == null || Sanitizer.GetSafeHtmlFragment(_User) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false)
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                if (_Password == null || Sanitizer.GetSafeHtmlFragment(_Password) == "")
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_User));
                _Array.Add(RSAPattern.Encrypt(_Password));

                string response = ApiHelper.PostData_Json_NToken("api/CPanel/LoginAuthentication?Val=", _Array);
                Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

                if (_Result.Data.Status == 1)
                {
                    _Result.Data.FirstName = "";
                    _Result.Data.LastName = "";
                    _Result.Data.Email = RSAPattern.Decrypt(_Result.Data.Email);
                    _Result.Data.Mobile = "";

                    SessionHandler.UserDetails = _Result.Data;

                    TokenAuthorization _Token = new TokenAuthorization();
                    System.Web.HttpContext.Current.Session["BearerToken"] = _Token.GenerateToken();

                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        private bool isCaptchaValid(string res)
        {
            var result = false;
            var captchaResponse = res;
            var secretKey = "6Le8IokUAAAAAJnKCaDOrbkMKVHaw9v1Cgq8GchF";
            var apiUrl = "https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}";
            var requestUri = string.Format(apiUrl, secretKey, captchaResponse);
            var request = (HttpWebRequest)WebRequest.Create(requestUri);

            using (WebResponse response = request.GetResponse())
            {
                using (StreamReader stream = new StreamReader(response.GetResponseStream()))
                {
                    JObject jResponse = JObject.Parse(stream.ReadToEnd());
                    var isSuccess = jResponse.Value<bool>("success");
                    result = (isSuccess) ? true : false;
                }
            }
            return result;
        }

        public ActionResult UserProfile()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult ChangePassword()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
    }
}