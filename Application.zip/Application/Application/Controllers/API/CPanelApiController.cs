﻿using Application.App_Start;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanel")]
    public class CPanelApiController : ApiController
    {
        CPanelDAL _ObjCPanel = new CPanelDAL();
        SharedDAL _ObjShared = new SharedDAL();

        [HttpPost, Route("LoginAuthentication")]
        public Result<SE_Users> LoginAuthentication(ArrayList Array)
        {
            SE_Users _Result = new SE_Users();
            try
            {
                List<string> _Data = new List<string>();
                foreach (string val in Array)
                    _Data.Add(RSAPattern.Decrypt(val));

                _Result = _ObjCPanel.AuthenticatedUser(StringEncrypt.Encrypt(_Data[0]), PwdEncryption.EncodePassword(_Data[1].ToString(), AES_Algorithm.DecryptString(_ObjShared.GetSaltKeyByEmail(StringEncrypt.Encrypt(_Data[0])))));
                _Result.RedirectUrl = Reusable.RedirectPage(_Result.RoleCode);

                if (_Result.RedirectUrl != null || _Result.RedirectUrl != "")
                {
                    _Result.FirstName = "";
                    _Result.LastName = "";
                    _Result.Email = RSAPattern.Encrypt(StringEncrypt.Decrypt(_Result.Email));
                    _Result.Mobile = "";

                    return Result.Success(_Result, 200, "Success", "Success");
                }
                else
                    return Result.Failed(_Result, 500, "Error", "Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("BindMenus")]
        public Result<string> BindMenus(ArrayList Array)
        {
            string _Role = string.Empty;
            try
            {
                foreach (string val in Array)
                    _Role = RSAPattern.Decrypt(val);

                string _Result = _ObjCPanel.GetMenus(_Role);
                _Result = _Result.Replace(Environment.NewLine, string.Empty).Trim();

                return Result.Success(_Result, 200, "Success", "Change Password is Succesfully");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
    }
}
