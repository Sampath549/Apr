﻿using Application.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class CPanelDevController : Controller
    {
        public ActionResult Dashboard()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateAllUsers()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult AllUserDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateRole()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateSubMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateAssignedMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateCountries()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateStates()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult ViewErrorLog()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }    
    }
}