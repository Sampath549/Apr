﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Application.Helper
{
    public sealed class GlobalVariables
    {
        private static readonly GlobalVariables shared = new GlobalVariables();
        public readonly string SessionExpired;

        static GlobalVariables()
        {
        }
        private GlobalVariables()
        {
            SessionExpired = WebConfigurationManager.AppSettings["SessionExpired"]; //Session Expired Page
        }
        public static GlobalVariables Shared
        {
            get
            {
                return shared;
            }
        }
    }
}