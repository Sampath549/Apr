﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Application.Helper
{
    public sealed class GlobalVariables
    {
        private static readonly GlobalVariables shared = new GlobalVariables();
        public readonly string SessionExpired;
        public readonly bool ReCaptcha;
        public readonly string PrivateKey;
        public readonly string PublicKey;
        public readonly string ConfigUrl;
        public readonly string AESKey;
        public readonly string InsertErrorLog;
        public readonly string BadRequest;
        public readonly string Unauthorized;
        public readonly string Forbidden;
        public readonly string NotFound;
        public readonly string InternalServerError;
        public readonly string SecureTokenKey;
        public int StudentRoleId;

        public string Host;
        public int Port;
        public string SenderEmail;
        public string EmailUser;
        public string EmailPwd;
        public bool DontSendMail;
        public bool SendActualMails;
        public string SendDefaultEmailTo;

        static GlobalVariables()
        {
        }
        private GlobalVariables()
        {
            SessionExpired = WebConfigurationManager.AppSettings["SessionExpired"]; //Session Expired Page
            ReCaptcha = Convert.ToBoolean(WebConfigurationManager.AppSettings["ReCaptcha"]); //ReCaptcha Validation
            PrivateKey = "<RSAKeyValue><Modulus>3SqgT67YOa+InXXxYLQgdcFxAtV3G6oHp9hUfyLciRtPHb0NcFsQ5ZjIB2VYFXc2NUIlysRo2hbmbWJMgU3gV/vL/ItQIb88owYFZx7Cd4qdQGTAw6xMh8RSl+mSHwMtMiJ8F3cZSEs9feXFLad0Yi7DonVl0NXoJU+I3eptEU0=</Modulus><Exponent>AQAB</Exponent><P>34LLnR5XdARSo0gf4JIhWBefsMnWLTwhgJZe+DfCrzqlAAm6ScDmx0bPL5RkH9+l28ngX0G1z5Cwwkoms6kyJw==</P><Q>/VCXbYcdvvJAjySZ9M6iFS4DasXy01X7AarySCBA+qw0vP0cQPqVhkbRlL+nufsvYkSgT4eZSphLKBE27eHtaw==</Q><DP>cPDKqo4Was10ZIWhdfzhVH47dz3GN/1WgH97Zbnnalwb3DUOKQ6Mjs29C7HUFjcQvEr6UagGkufuKX8Gp2orqQ==</DP><DQ>77x+E6J0fGo4v0AclJuaugC6Kyr8DRaqX4GxmqEr3hFsOBAz1StSp6oOX4Ci9FjNF2trbNkgMoC/YEQqgCf50Q==</DQ><InverseQ>vsHoBiTPU7B7TgwpbczYmFgdeaR5Qa3yYjtNdOiZlZ9bSeOuSA3SfJChAJjZaGkXhdl9Je9RunlrD9enPUrtJg==</InverseQ><D>HB8IZTlZGvSbzVGq0F325qIjCXY0/9p9wLS8AbJgEjrbs29PXyLlIhxsCqyzJ3+R7/GqNn8Eyf4xbGUcTzCkvq6Pc40tpmTrn6WK+zWia7Fza3db9/OP74VmBvMLhWCzlhfIcenb/00RaG+RH/gxdv9AOLw1ODW0F8Jap74cpI0=</D></RSAKeyValue>";
            PublicKey = WebConfigurationManager.AppSettings["PublicKey"].ToString();
            ConfigUrl = WebConfigurationManager.AppSettings["ConfigUrl"].ToString();
            AESKey = WebConfigurationManager.AppSettings["AESKey"].ToString();
            InsertErrorLog = WebConfigurationManager.AppSettings["InsertErrorLog"].ToString();
            BadRequest = WebConfigurationManager.AppSettings["BadRequest"]; //Error Page
            Unauthorized = WebConfigurationManager.AppSettings["Unauthorized"]; //Error Page
            Forbidden = WebConfigurationManager.AppSettings["Forbidden"]; //Error Page
            NotFound = WebConfigurationManager.AppSettings["NotFound"]; //Error Page
            InternalServerError = WebConfigurationManager.AppSettings["InternalServerError"]; //Error Page
            SecureTokenKey = WebConfigurationManager.AppSettings["SecureTokenKey"];
            StudentRoleId = 3;

            //Email
            Host = WebConfigurationManager.AppSettings["MailingHost"].ToString();
            Port = Convert.ToInt32(WebConfigurationManager.AppSettings["MailingPort"]);
            SenderEmail = WebConfigurationManager.AppSettings["SenderEmail"].ToString();
            EmailUser = WebConfigurationManager.AppSettings["EmailUser"].ToString();
            EmailPwd = WebConfigurationManager.AppSettings["EmailPwd"].ToString();
            DontSendMail = Convert.ToBoolean(WebConfigurationManager.AppSettings["DontSendMail"]);
            SendActualMails = Convert.ToBoolean(WebConfigurationManager.AppSettings["SendActualMails"]);
            SendDefaultEmailTo = WebConfigurationManager.AppSettings["SendDefaultEmailTo"].ToString();
        }
        public static GlobalVariables Shared
        {
            get { return shared; }
        }
    }
}