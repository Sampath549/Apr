﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelAdminDAL : DataAccessComponent
    {
        public int SaveUpdateCourseCategory(string Code, string Desc, string btnType)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CourseCategory";
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = Desc;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}