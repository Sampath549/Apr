﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

$(document).ready(function () {

    $('#btnSaveDetails').val("Save");

    $("#CreateCourseCategory").validate({
        rules: {
            'CCCode': {
                required: true,
                minlength: 2,
                maxlength: 5,
                lettersonly: true
            },
            'CCDesc': {
                required: true,
                maxlength: 30
            }
        },
        messages: {
            'CCCode': {
                required: 'Enter Code',
                minlength: 'Must enter Minimum of 2 characters',
                maxlength: 'Must enter Maximum of 5 characters'
            },
            'CCDesc': {
                required: 'Enter Description',
                maxlength: 'Must enter Maximum of 30 characters'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {
                var _postData = {
                    Code: $('#CCCode').val(),
                    Description: $('#CCDesc').val(),
                    ButtonType: $('#btnSaveDetails').val()
                };
                console.log(_postData);
                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/CourseCategory",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
    $("#btnCancel").click(function () {
        ClearFields();
    });
});

function ClearFields() {
    $("#CUFName").val('');
    $("#CULName").val('');
    $('#CUEmail').val('');
    $('#CUMobile').val('');
}