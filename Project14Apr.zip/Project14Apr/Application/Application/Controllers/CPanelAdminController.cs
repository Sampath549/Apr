﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class CPanelAdminController : Controller
    {
        public ActionResult Dashboard()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult RequestForms()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CreateStudent()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateStudents(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Email == null || Sanitizer.GetSafeHtmlFragment(_User.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Mobile == null || Sanitizer.GetSafeHtmlFragment(_User.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Mobile).Length != 10)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers with 10 digits"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.Email = RSAPattern.Encrypt(_User.Email);
                Users.Mobile = RSAPattern.Encrypt(_User.Mobile);
                Users.RoleIdVal = RSAPattern.Encrypt(GlobalVariables.Shared.StudentRoleId.ToString());

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json("api/CPanelDev/CreateAllUsers?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult StudentDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult UploadDocuments()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult UploadVideos()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CourseCategory()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CourseCategory(string Code, string Description, string ButtonType)
        {
            try
            {
                if (ButtonType == "Save")
                {
                    if (Code == null || Sanitizer.GetSafeHtmlFragment(Code) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Code), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Code).Length > 5 || Sanitizer.GetSafeHtmlFragment(Code).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Code should not be Empty and must contain only Alphabets with Min of 2 & Max of 5 characters"), JsonRequestBehavior.AllowGet);
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 30 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Min of 2 & Max of 30 characters"), JsonRequestBehavior.AllowGet);
                }
                else if (ButtonType == "Update")
                {
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 30 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Min of 2 & Max of 30 characters"), JsonRequestBehavior.AllowGet);
                }

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(Code));
                _Array.Add(RSAPattern.Encrypt(Description));
                _Array.Add(RSAPattern.Encrypt(ButtonType));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/CourseCategory?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CreateCourse()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CourseDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CourseContent()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CreateBatch()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult BatchDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult ContactUsForm()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
    }
}