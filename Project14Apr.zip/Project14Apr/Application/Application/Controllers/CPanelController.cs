﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class CPanelController : Controller
    {
        SE_Users Users = new SE_Users();
        ArrayList _Array = new ArrayList();
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult LoginAuthentication(string _User, string _Password, string _ReCaptcha)
        {
            try
            {
                //Checking ReCaptcha Required or Not
                if (GlobalVariables.Shared.ReCaptcha)
                {
                    bool chk = isCaptchaValid(_ReCaptcha);
                    if (!chk)
                        return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                }

                //Server-Side Validations
                if (_User == null || Sanitizer.GetSafeHtmlFragment(_User) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false)
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                if (_Password == null || Sanitizer.GetSafeHtmlFragment(_Password) == "")
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);

                //API Call
                _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_User));
                _Array.Add(RSAPattern.Encrypt(_Password));

                string response = ApiHelper.PostData_Json_NToken("api/CPanel/LoginAuthentication?Values=", _Array);
                Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

                if (_Result.Data.Status == 1)
                {
                    _Result.Data.FirstName = RSAPattern.Decrypt(_Result.Data.FirstName);
                    _Result.Data.LastName = RSAPattern.Decrypt(_Result.Data.LastName);
                    _Result.Data.Email = RSAPattern.Decrypt(_Result.Data.Email);
                    _Result.Data.Mobile = RSAPattern.Decrypt(_Result.Data.Mobile);

                    SessionHandler.UserDetails = _Result.Data;

                    TokenAuthorization _Token = new TokenAuthorization();
                    System.Web.HttpContext.Current.Session["BearerToken"] = _Token.GenerateToken();

                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        private bool isCaptchaValid(string res)
        {
            var result = false;
            var captchaResponse = res;
            var secretKey = "6Le8IokUAAAAAJnKCaDOrbkMKVHaw9v1Cgq8GchF";
            var apiUrl = "https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}";
            var requestUri = string.Format(apiUrl, secretKey, captchaResponse);
            var request = (HttpWebRequest)WebRequest.Create(requestUri);

            using (WebResponse response = request.GetResponse())
            {
                using (StreamReader stream = new StreamReader(response.GetResponseStream()))
                {
                    JObject jResponse = JObject.Parse(stream.ReadToEnd());
                    var isSuccess = jResponse.Value<bool>("success");
                    result = (isSuccess) ? true : false;
                }
            }
            return result;
        }
        public ActionResult UserProfile()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.Gender_ddl = Reusable.GenderList();
            ViewBag.Countries = Reusable.CountriesList();
            ViewBag.States = Reusable.StatesList();

            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            ArrayList _Array = new ArrayList();
            _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.Email));
            string response = ApiHelper.PostData_Json("api/CPanel/UserDetails?Values=", _Array);
            Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

            SE_Users Users = new SE_Users();
            Users.FirstName = _SessionUserDetails.FirstName;
            Users.LastName = _SessionUserDetails.LastName;
            Users.Email = _SessionUserDetails.Email;
            Users.Mobile = _SessionUserDetails.Mobile;
            Users.RoleCode = _SessionUserDetails.RoleCode;
            if (_Result.Data.Gender != null)
                Users.Gender = RSAPattern.Decrypt(_Result.Data.Gender);
            if (_Result.Data.Address != null)
                Users.Address = RSAPattern.Decrypt(_Result.Data.Address);
            if (_Result.Data.City != null)
                Users.City = RSAPattern.Decrypt(_Result.Data.City);
            if (_Result.Data.StateId != null)
                Users.StateId = _Result.Data.StateId;
            if (_Result.Data.CountryId != null)
                Users.CountryId = _Result.Data.CountryId;
            if (_Result.Data.ZipCode != null)
                Users.ZipCode = RSAPattern.Decrypt(_Result.Data.ZipCode);

            return View(Users);
        }
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult UserProfile(SE_Users UserDetails)
        {
            SE_Users _User = new SE_Users();
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                //Server-Side Validations
                if (UserDetails.FirstName == null || Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName).Length > 35)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with not more than of 35 characters"), JsonRequestBehavior.AllowGet);
                if (UserDetails.LastName == null || Sanitizer.GetSafeHtmlFragment(UserDetails.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(UserDetails.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(UserDetails.LastName).Length > 35)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with not more than of 35 characters"), JsonRequestBehavior.AllowGet);
                if (UserDetails.ZipCode != null || Sanitizer.GetSafeHtmlFragment(UserDetails.ZipCode) == "")
                    if (Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(UserDetails.ZipCode), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(UserDetails.ZipCode).Length > 10)
                        return Json(new Result(false, 500, "Validation Error", "Zip Code must contain only Numbers with not more than 10 Digits"), JsonRequestBehavior.AllowGet);

                //RSA Encryption	   
                _User.UserId = _SessionUserDetails.UserId;
                _User.FirstName = RSAPattern.Encrypt(UserDetails.FirstName);
                _User.LastName = RSAPattern.Encrypt(UserDetails.LastName);
                _User.Email = RSAPattern.Encrypt(UserDetails.Email);
                if (UserDetails.Gender != "0")
                    _User.Gender = RSAPattern.Encrypt(UserDetails.Gender);
                if (UserDetails.Address != null)
                    _User.Address = RSAPattern.Encrypt(UserDetails.Address);
                if (UserDetails.City != null)
                    _User.City = RSAPattern.Encrypt(UserDetails.City);
                if (UserDetails.StateId != "0")
                    _User.StateId = RSAPattern.Encrypt(UserDetails.StateId);
                if (UserDetails.CountryId != "0")
                    _User.CountryId = RSAPattern.Encrypt(UserDetails.CountryId);
                if (UserDetails.ZipCode != null)
                    _User.ZipCode = RSAPattern.Encrypt(UserDetails.ZipCode);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_User);
                string response = ApiHelper.PostData_Json("api/CPanel/UserProfile?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                SE_Users _RedirectResult = new SE_Users();
                _RedirectResult.RedirectUrl = Reusable.RedirectPage(_SessionUserDetails.RoleCode);

                if (_Result.Status)
                {
                    _SessionUserDetails.FirstName = UserDetails.FirstName;
                    _SessionUserDetails.LastName = UserDetails.LastName;
                    SessionHandler.UserDetails = _SessionUserDetails;
                }
                return Json(new Result<SE_Users>(_RedirectResult, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult ChangePassword()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult ChangePassword(string OldPassword, string Password, string CPassword)
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            var score = 0;
            try
            {
                //Server-Side Validations		
                if (OldPassword == null || Sanitizer.GetSafeHtmlFragment(OldPassword) == "" || Sanitizer.GetSafeHtmlFragment(OldPassword).Length < 8 || Sanitizer.GetSafeHtmlFragment(OldPassword).Length > 50)
                    return Json(new Result(false, 500, "Validation Error", "Old Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password.Length >= 8 && Password.Length < 50)
                {
                    score = 0;

                    if (Regex.Match(Password, @"\d", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[a-z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[A-Z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[!,@,#,$,%,^,&,*,?,_,~,-,£,(,),\s]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (score < 4)
                        return Json(new Result(false, 500, "Validation Error", "New Password should contain minmum 1 Upper character, 1 Lower character, 1 Number and 1 Special character."), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result(false, 500, "Validation Error", "Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password != CPassword)
                    return Json(new Result(false, 500, "Validation Error", "Password and Confirm Password should be same"), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(OldPassword));
                _Array.Add(RSAPattern.Encrypt(Password));
                _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.UserId.ToString()));
                string response = ApiHelper.PostData_Json("api/CPanel/ChangePassword?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                if (_Result.Status == true)
                {
                    _SessionUserDetails.IsFirstTimeLogin = false;
                    SessionHandler.UserDetails = _SessionUserDetails;
                }

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
    }
}