﻿using Application.App_Start;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanelAdmin")]
    public class CPanelAdminApiController : ApiController
    {
        SE_Users Users = new SE_Users();
        CPanelAdminDAL _ObjCPanelAdmin = new CPanelAdminDAL();

        [HttpPost, Route("CourseCategory")]
        public Result CourseCategory(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val));

                int _Result = _ObjCPanelAdmin.SaveUpdateCourseCategory(_lst[0], _lst[1], _lst[2]);

                if (_Result == 1 && _lst[2].ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && _lst[2].ToString() == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Code");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
    }
}
