USE steptek

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [USP_Get_AuthenticatedUser]
( 
 @EmailId	VARCHAR(800),  
 @Password	VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	DECLARE @Status					VARCHAR(5),  
			@UserId					INT = NULL,  
			@FirstName				VARCHAR(800) = NULL,
			@LastName				VARCHAR(800) = NULL,
			@FullName				VARCHAR(800) = NULL,
			@Email					VARCHAR(800) = NULL,
			@Mobile					VARCHAR(800) = NULL,
			@RoleId					INT = NULL,  
			@RoleCode				VARCHAR(50) = NULL,  
			@IsFirstTimeLogin		BIT = NULL,
			@ProfilePic				VARCHAR(MAX) = NULL

	IF (SELECT Count(*) FROM [StepTekDB].[tbl_Users] WHERE Email = @EmailId AND @Password = @Password) = 0  
		BEGIN  
			SET @Status = 0   
		END  
	ELSE  
		BEGIN  
			SELECT  @Status = 1,  
					@UserId = U.UserId,  
					@FirstName = U.FirstName,  
					@LastName = U.LastName, 
					@FullName = (U.FirstName + ' ' + U.LastName),  
					@Email = U.Email,  
					@Mobile = U.Mobile,  
					@RoleId = U.RoleId,  
					@RoleCode = R.Code,  
					@ProfilePic = U.Photo,
					@IsFirstTimeLogin = U.IsFirstTimeLogin
			FROM   
				[StepTekDB].[tbl_Users] U
			INNER JOIN [StepTekDB].[Ref_Roles] R ON U.RoleId = R.RoleId
			WHERE U.Email = @EmailId  AND U.[Password] = @Password

			IF (SELECT Count(*) FROM [StepTekDB].[tbl_UserMapping] WHERE UserId = @UserId) = 0  
				BEGIN
					INSERT INTO [StepTekDB].[tbl_UserMapping] (UserId) VALUES (@UserId)
				END
	  END  

	SELECT  @Status AS [Status],
			@UserId AS UserId,
			@FirstName AS FirstName,
			@LastName AS LastName,
			@FullName AS FullName,
			@Email AS Email,
			@Mobile AS Mobile,
			@RoleId AS RoleId, 
			@RoleCode AS RoleCode,
			@ProfilePic AS Photo,
			@IsFirstTimeLogin AS IsFirstTimeLogin
END 
--EXEC USP_Get_AuthenticatedUser 'GLlFWpU4PZsR+jb7S1PkGyvwFX9EHwCBLkie7NeA9o8=','Nky5VhXfD6T9ZLaUWTO5BNeu+rMdVMz4X96RSeKh7mg='
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [USP_Get_MenuListByRole]
(
	@RoleCode	VARCHAR(10)
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RoleId INT
	SET @RoleId= (SELECT RoleId FROM [StepTekDB].[Ref_Roles] WHERE Code = @RoleCode)

	SELECT
		AM.ParentId,
		M.Header,
		M.Controller,
		M.[Action],
		M.HavingChild,
		M.[Order],
		M.Icon
	FROM [StepTekDB].[tbl_AssignMenus] AS AM
	INNER JOIN [StepTekDB].[tbl_Menus] M ON M.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId
	
	SELECT
		AM.ParentId,
		SM.Header,
		SM.Controller,
		SM.[Action],
		SM.[Order]
	FROM [tbl_AssignMenus] AS AM
	INNER JOIN [StepTekDB].[tbl_SubMenus] SM ON SM.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId	

END
-- EXEC USP_Get_MenuListByRole 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [USP_Get_UserDetails]
( 
 @Email	VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	DECLARE @UserId INT
	
	IF (SELECT Count(*) FROM [StepTekDB].[tbl_Users] WHERE Email = @Email) > 0  
		BEGIN  
			SET @UserId= (SELECT UserId FROM [StepTekDB].[tbl_Users] WHERE Email = @Email)

			SELECT	U.UserId,
					U.Gender,
					UM.PermanentStreetAddress [Address],
					UM.PermanentCity [City],
					UM.PermanentState [StateId],
					UM.PermanentCountry [CountryId],
					UM.PermanentZipCode [ZipCode]
			FROM   
				[StepTekDB].[tbl_Users] U
			INNER JOIN [StepTekDB].[tbl_UserMapping] UM ON U.UserId = UM.UserId
			WHERE U.UserId = @UserId
		END  
END 
-- EXEC [USP_Get_UserDetails] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [USP_Update_UserProfile]
(
	@Email				VARCHAR(800),
	@FirstName			VARCHAR(800),
	@LastName			VARCHAR(800),
	@Gender				VARCHAR(500) = NULL,
	@Address			VARCHAR(800) = NULL,
	@City				VARCHAR(800) = NULL,
	@StateId			INT = NULL,
	@CountryId			INT = NULL,
	@ZipCode			BIGINT = NULL,
	@OutputResult		INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		
	BEGIN TRY
		
		DECLARE @UserId INT
		SET @UserId= (SELECT UserId FROM [StepTekDB].[tbl_Users] WHERE Email = @Email)
		
		BEGIN
			UPDATE [StepTekDB].[tbl_Users] SET [FirstName] = @FirstName, [LastName] = @LastName, [Gender] = @Gender  WHERE UserId = @UserId
			UPDATE [StepTekDB].[tbl_UserMapping] 
						SET [IsPermanentAddress] = 1,	
							[PermanentStreetAddress] = @Address,
							[PermanentCity] = @City,
							[PermanentState] = @StateId,
							[PermanentCountry] = @CountryId,
							[PermanentZipCode] = @ZipCode,
							[CurrentStreetAddress] = NULL,
							[CurrentCity] = NULL,
							[CurrentState] = NULL,
							[CurrentCountry] = NULL,
							[CurrentZipCode] = NULL
						WHERE UserId = @UserId
			SET @OutputResult = 1	
		END	
				
	END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				SET @OutputResult = 0
				ROLLBACK TRANSACTION MySavePoint; 
			END
		END CATCH
		COMMIT TRANSACTION 
	END	
--EXEC [USP_Update_UserProfile]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_Update_ChangePassword]
(
	@UserId INT ,
	@OldPwd VARCHAR(800),
	@OldKey VARCHAR(800),
	@NewPwd VARCHAR(800),
	@NewKey VARCHAR(800),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Users] WHERE UserId = @UserId) > 0)
		BEGIN
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Users] WHERE [Password] = @OldPwd AND SaltKey = @OldKey) > 0)
				BEGIN
					UPDATE [StepTekDB].[tbl_Users] SET [Password] = @NewPwd , SaltKey = @NewKey, IsFirstTimeLogin = 0 WHERE UserId = @UserId
					SET @OutPut = 1 
				END
			ELSE
				SET @OutPut = 99 -- Old Password Incorrect
		END
	ELSE
		SET @OutPut = 100 -- No User
END
-- EXEC [USP_Update_ChangePassword] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_Insert_Users]
( 
  @PersonalKey      VARCHAR(800),
  @FirstName		VARCHAR(800),
  @LastName         VARCHAR(800),
  @Email            VARCHAR(800),
  @Mobile           VARCHAR(800),
  @RoleId	        VARCHAR(10),
  @Password         VARCHAR(800),
  @SaltKey          VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 
	INSERT INTO [StepTekDB].[tbl_Users] (PersonalKey, FirstName, LastName, Email, Mobile, RoleId, [Password], SaltKey, [CreatedDate])
	VALUES (@PersonalKey, @FirstName, @LastName, @Email, @Mobile, @RoleId, @Password, @SaltKey, GETDATE())
END		
-- EXEC [USP_Insert_Users]