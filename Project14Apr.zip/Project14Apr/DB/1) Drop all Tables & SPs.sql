USE steptek

DROP TABLE [Ref_Roles]
DROP TABLE [tbl_Users]
DROP TABLE [Ref_Countries]
DROP TABLE [Ref_States]
DROP TABLE [tbl_UserMapping]
DROP TABLE [tbl_ResetPwdLog]
DROP TABLE [tbl_Menus]
DROP TABLE [tbl_SubMenus]
DROP TABLE [tbl_AssignMenus]

DROP PROCEDURE [USP_Get_AuthenticatedUser]
DROP PROCEDURE [USP_Get_MenuListByRole]
DROP PROCEDURE [USP_Get_UserDetails]
DROP PROCEDURE [USP_Update_UserProfile]
DROP PROCEDURE [USP_Update_ChangePassword]
DROP PROCEDURE [USP_Insert_Users]