﻿using Ganss.XSS;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace Application.Helper
{
    public class EmailHelper : IDisposable
    {
        SmtpClient smtpclient;
        private static readonly Lazy<EmailHelper> lazy_instance = new Lazy<EmailHelper>(() => new EmailHelper());
        public static EmailHelper Instance { get { return lazy_instance.Value; } }
        private static readonly Regex RenderRegex = new Regex(@"{{([a-z0-9_.\-]+)}}", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        public static string Render(string str, Dictionary<string, string> values)
        {
            StringBuilder renderedtext = new StringBuilder();
            renderedtext.Append(str);
            foreach (Match match in RenderRegex.Matches(str))
            {
                if (values.ContainsKey(match.Groups[1].Value))
                {

                    renderedtext.Replace(match.Groups[0].Value, values[match.Groups[1].Value]);
                }
            }
            Console.WriteLine(renderedtext.ToString());
            return (renderedtext.ToString());
        }
        private EmailHelper()
        {
            smtpclient = new SmtpClient();
            smtpclient.Host = GlobalVariables.Shared.Host;
            smtpclient.Port = GlobalVariables.Shared.Port;
            smtpclient.UseDefaultCredentials = false;
            smtpclient.Credentials = new System.Net.NetworkCredential(GlobalVariables.Shared.EmailUser, GlobalVariables.Shared.EmailPwd);
            smtpclient.EnableSsl = true;
            smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpclient.ServicePoint.MaxIdleTime = 0;
            smtpclient.ServicePoint.SetTcpKeepAlive(true, 2000, 2000);
        }
        public bool SendWithTemplate(string email_to, string email_cc_to, string email_subject, string email_body, List<EmailAttachment> attachments)
        {
            string template_path = System.Web.Hosting.HostingEnvironment.MapPath("~/Helper/Documents/MasterTemplate.html");
            Dictionary<string, string> template_value = new Dictionary<string, string>
            {
                ["content"] = email_body
            };
            return SendTemplate(email_to, email_cc_to, email_subject, template_value, attachments, template_path);
        }
        public bool SendTemplate(string email_to, string email_cc_to, string email_subject, Dictionary<string, string> template_value, List<EmailAttachment> attachments, string template_path)
        {
            String template = File.ReadAllText(template_path);
            string email_body = Render(template, template_value);
            return SendHTMLEmail(email_to, email_cc_to, email_subject, email_body, attachments);
        }
        public bool SendHTMLEmail(string email_to, string email_cc_to, string email_subject, string email_body, List<EmailAttachment> attachments)
        {
            MailMessage message = new MailMessage();
            message.To.Add(email_to);
            if (email_cc_to != "")
                message.CC.Add(email_cc_to);
            message.Subject = email_subject;
            message.From = new MailAddress(GlobalVariables.Shared.SenderEmail);
            message.IsBodyHtml = true;

            EmailImage emailimg = new EmailImage(email_body);
            AlternateView alt_view = AlternateView.CreateAlternateViewFromString(emailimg.ToString(), null, MediaTypeNames.Text.Html);
            message.AlternateViews.Add(alt_view);
            emailimg.imagelist.ForEach(x => { alt_view.LinkedResources.Add(x); });
            foreach (var attachment in attachments)
            {
                Attachment data = new Attachment(new MemoryStream(attachment.data), attachment.name);
                message.Attachments.Add(data);
            }

            message.BodyEncoding = Encoding.Default;
            message.Priority = MailPriority.High;
            bool status = SendEmail(message);
            return status;
        }
        private bool SendEmail(MailMessage message)
        {
            try
            {
                smtpclient.Send(message);
                return true;
            }
            catch (WebException ex)
            {
                System.Diagnostics.Trace.Flush();
                System.Diagnostics.Debug.Flush();
                throw ex;
            }
        }
        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    this.smtpclient.Dispose();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }
        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~EmailHelper() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }
        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
        public string HTMLSanitize(string unsanitize)
        {
            var sanitizer = new HtmlSanitizer();
            sanitizer.AllowedSchemes.Add("mailto");
            sanitizer.AllowedSchemes.Add("http");
            sanitizer.AllowedSchemes.Add("https");
            var sanitized = sanitizer.Sanitize(unsanitize);
            return sanitized;
        }
    }
    public class EmailAttachment
    {
        public string name;
        public byte[] data;
        public EmailAttachment(string attachmentname, byte[] data)
        {
            this.name = attachmentname;
            this.data = data;
        }
    };
    public class EmailImage
    {
        string emailbody;
        public List<LinkedResource> imagelist;
        private static readonly Regex RenderRegex = new Regex("\"data:(?<type>.+?);base64,(?<data>[^\"]+)\"", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        public EmailImage(string emailbody)
        {
            this.emailbody = emailbody;
            imagelist = new List<LinkedResource> { };
            ProcessInlineImgSrc();
        }
        public override string ToString()
        {
            return (this.emailbody);
        }
        public void ProcessInlineImgSrc()
        {
            foreach (Match match in RenderRegex.Matches(this.emailbody))
            {
                var base64Data = match.Groups["data"].Value;
                var contentType = match.Groups["type"].Value;
                LinkedResource img = new LinkedResource(new MemoryStream(Convert.FromBase64String(base64Data)), contentType);
                img.ContentId = Guid.NewGuid().ToString().Trim();
                img.ContentType.MediaType = contentType;
                img.TransferEncoding = TransferEncoding.Base64;
                img.ContentType.Name = img.ContentId;
                img.ContentLink = new Uri("cid:" + img.ContentId);
                imagelist.Add(img);
                this.emailbody = this.emailbody.Replace(match.Groups[0].Value, "'cid:" + img.ContentId + "'");
            }
        }
    };
}