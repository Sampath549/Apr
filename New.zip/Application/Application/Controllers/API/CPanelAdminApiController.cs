﻿using Application.App_Start;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanelAdmin")]
    public class CPanelAdminApiController : ApiController
    {
        SE_Users Users = new SE_Users();
        CPanelAdminDAL _ObjCPanelAdmin = new CPanelAdminDAL();

        [HttpPost, Route("GetStudentDetails")]
        public Result<List<SE_Users>> GetStudentDetails(ArrayList Array)
        {
            List<SE_Users> _lst = new List<SE_Users>();
            try
            {
                _lst = _ObjCPanelAdmin.GetStudentDetails();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("EditStudentDetails")]
        public Result<SE_Users> EditStudentDetails(ArrayList Array)
        {
            List<SE_Users> _lst = new List<SE_Users>();
            string _id = string.Empty;
            try
            {
                foreach (string val in Array)
                    _id = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelAdmin.EditStudentDetails(Convert.ToInt32(_id));
                return Result.Success(_lst[0], 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("UpdateStudentDetails")]
        public Result UpdateStudentDetails(ArrayList Array)
        {
            try
            {
                Users = new SE_Users();
                foreach (JObject val in Array)
                    Users = val.ToObject<SE_Users>();

                Users.UserId = Users.UserId;
                Users.FirstName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Users.FirstName));
                Users.LastName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Users.LastName));
                Users.IsActive = Users.IsActive;

                int _Status = _ObjCPanelAdmin.UpdateStudentDetails(Users);

                if (_Status == 1)
                    return Result.Success(200, "Success", "User Created Successfully");
                else if (_Status == 101)
                    return Result.Failed(500, "UnAuthorized", "Not Authorized to Change the Details");
                else if (_Status == 100)
                    return Result.Failed(500, "No User", "No Record Exits");
                else
                    return Result.Failed(500, "Internal Server Error", "Something went Wrong");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("GetCourseCategory")]
        public Result<List<SE_RefValues>> GetCourseCategory(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourseCategory();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateCourseCategory")]
        public Result InsertUpdateCourseCategory(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val));

                int _Result = _ObjCPanelAdmin.InsertUpdateCourseCategory(_lst[0], _lst[1], _lst[2]);

                if (_Result == 1 && _lst[2].ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && _lst[2].ToString() == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Code");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteCourseCategory")]
        public Result DeleteCourseCategory(ArrayList Array)
        {
            string _val = string.Empty;
            try
            {
                foreach (string val in Array)
                    _val = val.ToString();

                string Code = string.Empty;
                Code = RSAPattern.Decrypt(_val);

                int _Result = _ObjCPanelAdmin.DeleteCourseCategory(Code);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "Refered With Other Records");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("CourseCategoryList")]
        public Result<List<SE_RefValues>> CourseCategoryList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.CourseCategoryList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("GetCourse")]
        public Result<List<SE_Course>> GetCourse(ArrayList Array)
        {
            List<SE_Course> _lst = new List<SE_Course>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourse();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateCreateCourse")]
        public Result InsertUpdateCreateCourse(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val));

                SE_Course _Course = new SE_Course();
                _Course.CategoryId = Convert.ToInt32(_lst[0]);
                _Course.Title = Convert.ToString(_lst[1]);
                _Course.Desc = Convert.ToString(_lst[2]);
                _Course.btnType = Convert.ToString(_lst[3]);

                int _Result = _ObjCPanelAdmin.InsertUpdateCreateCourse(_Course);

                if (_Result == 1 && _Course.btnType.ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && _Course.btnType.ToString() == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Title");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteCourse")]
        public Result DeleteCourse(ArrayList Array)
        {
            string Title = string.Empty;
            try
            {
                foreach (string val in Array)
                    Title = RSAPattern.Decrypt(val.ToString());

                int _Result = _ObjCPanelAdmin.DeleteCourse(Title);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("GetCourseDetails")]
        public Result<List<SE_CourseDetails>> GetCourseDetails(ArrayList Array)
        {
            List<SE_CourseDetails> _lst = new List<SE_CourseDetails>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourseDetails();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("CourseList")]
        public Result<List<SE_RefValues>> CourseList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.CourseList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateCourseDetails")]
        public Result InsertUpdateCourseDetails(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                int i = 0;
                int Count = Array.Count;
                foreach (string val in Array)
                {
                    if (i == Array.Count - 3)
                        _lst.Add(val);
                    else
                    {
                        if (val != null)
                            _lst.Add(RSAPattern.Decrypt(val));
                        else
                            _lst.Add(null);
                    }
                    i++;
                }

                int _Result = _ObjCPanelAdmin.InsertUpdateCourseDetails(_lst[0], _lst[1], _lst[2], _lst[3], _lst[4], _lst[5], _lst[6], _lst[7], _lst[8]);

                if (_Result == 1 && _lst[8].ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                else if (_Result == 1 && _lst[8].ToString() == "Update")
                    return Result.Success(200, "Success", "Record Updated Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Already Exists");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("EditCourseDetails")]
        public Result<SE_CourseDetails> EditCourseDetails(ArrayList Array)
        {
            List<SE_CourseDetails> _lst = new List<SE_CourseDetails>();
            string _id = string.Empty;
            try
            {
                foreach (string val in Array)
                    _id = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelAdmin.EditCourseDetails(Convert.ToInt32(_id));
                return Result.Success(_lst[0], 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteCourseDetails")]
        public Result DeleteCourseDetails(ArrayList Array)
        {
            string ID = string.Empty;
            try
            {
                foreach (string val in Array)
                    ID = RSAPattern.Decrypt(val.ToString());

                int _Result = _ObjCPanelAdmin.DeleteCourseDetails(ID);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("GetCourseContent")]
        public Result<List<SE_CourseContent>> GetCourseContent(ArrayList Array)
        {
            List<SE_CourseContent> _lst = new List<SE_CourseContent>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourseContent();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateCourseContent")]
        public Result InsertUpdateCourseContent(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                int i = 0;
                int Count = Array.Count;
                foreach (string val in Array)
                {
                    if (i == Array.Count - 2)
                        _lst.Add(val);
                    else
                    {
                        if (val != null)
                            _lst.Add(RSAPattern.Decrypt(val));
                        else
                            _lst.Add(null);
                    }
                    i++;
                }

                int _Result = _ObjCPanelAdmin.InsertUpdateCourseContent(_lst[0], _lst[1], _lst[2], _lst[3]);

                if (_Result == 1 && _lst[3].ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && _lst[3].ToString() == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Code");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteCourseContent")]
        public Result DeleteCourseContent(ArrayList Array)
        {
            string _val = string.Empty;
            try
            {
                foreach (string val in Array)
                    _val = val.ToString();

                string ID = string.Empty;
                ID = RSAPattern.Decrypt(_val);

                int _Result = _ObjCPanelAdmin.DeleteCourseContent(ID);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "Refered With Other Records");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("StudentsList")]
        public Result<List<SE_RefValues>> StudentsList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.StudentsList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
    }
}
