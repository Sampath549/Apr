﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class CPanelAdminController : Controller
    {
        public ActionResult Dashboard()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult RequestForms()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CreateStudent()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateStudents(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Email == null || Sanitizer.GetSafeHtmlFragment(_User.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Mobile == null || Sanitizer.GetSafeHtmlFragment(_User.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Mobile).Length != 10)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers with 10 digits"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.Email = RSAPattern.Encrypt(_User.Email);
                Users.Mobile = RSAPattern.Encrypt(_User.Mobile);
                Users.RoleIdVal = RSAPattern.Encrypt(GlobalVariables.Shared.StudentRoleId.ToString());

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json("api/CPanelDev/CreateAllUsers?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult StudentDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetStudentDetails()
        {
            List<SE_Users> _list = new List<SE_Users>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _UsersData = ApiHelper.PostData_Json("api/CPanelAdmin/GetStudentDetails?Values=", _Array);
                Result<List<SE_Users>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Users>>>(_UsersData);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.UserId),
                                 Convert.ToString(AES_Algorithm.DecryptString(c.FirstName) + " " + AES_Algorithm.DecryptString(c.LastName)),
                                 Convert.ToString(AES_Algorithm.DecryptString(c.FirstName)),
                                 Convert.ToString((AES_Algorithm.DecryptString(c.LastName))),
                                 Convert.ToString((StringEncrypt.Decrypt(c.Email))),
                                 Convert.ToString((StringEncrypt.Decrypt(c.Mobile))),
                                 Convert.ToString(c.RoleDesc),
                                 Convert.ToString(c.IsActive),
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult EditStudentDetails(int id)
        {
            SE_Users model = new SE_Users();
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(id.ToString()));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/EditStudentDetails?Values=", _Array);
                Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

                if (_Result.Status)
                {
                    model.UserId = _Result.Data.UserId;
                    model.FullName = AES_Algorithm.DecryptString(_Result.Data.FirstName) + " " + AES_Algorithm.DecryptString(_Result.Data.LastName);
                    model.FirstName = AES_Algorithm.DecryptString(_Result.Data.FirstName);
                    model.LastName = AES_Algorithm.DecryptString(_Result.Data.LastName);
                    model.Email = StringEncrypt.Decrypt(_Result.Data.Email);
                    model.Mobile = StringEncrypt.Decrypt(_Result.Data.Mobile);
                    model.RoleId = _Result.Data.RoleId;
                    model.RoleDesc = _Result.Data.RoleDesc;
                    model.IsActive = _Result.Data.IsActive;
                }

                return View("../PartialViews/StudentDetailsSideBar", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult UpdateStudentDetails(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.UserId = _User.UserId;
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.IsActive = _User.IsActive;

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/UpdateStudentDetails?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult UploadDocuments()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult UploadVideos()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CourseCategory()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetCourseCategory()
        {
            List<SE_RefValues> _list = new List<SE_RefValues>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourseCategory?Values=", _Array);
                Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.Id),
                                 Convert.ToString(c.Code),
                                 Convert.ToString(c.Description)
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateCourseCategory(string Code, string Description, string ButtonType)
        {
            try
            {
                if (ButtonType == "Save")
                {
                    if (Code == null || Sanitizer.GetSafeHtmlFragment(Code) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Code), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Code).Length > 5 || Sanitizer.GetSafeHtmlFragment(Code).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Code should not be Empty and must contain only Alphabets with Min of 2 & Max of 5 characters"), JsonRequestBehavior.AllowGet);
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 30 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Min of 2 & Max of 30 characters"), JsonRequestBehavior.AllowGet);
                }
                else if (ButtonType == "Update")
                {
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 30 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Min of 2 & Max of 30 characters"), JsonRequestBehavior.AllowGet);
                }

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(Code));
                _Array.Add(RSAPattern.Encrypt(Description));
                _Array.Add(RSAPattern.Encrypt(ButtonType));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCourseCategory?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourseCategory(string Code)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(Code));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourseCategory?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CreateCourse()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.CCategory_dll = Reusable.CourseCategoryList(); // All Categories
            return View();
        }

        public JsonResult GetCourse()
        {
            List<SE_Course> _list = new List<SE_Course>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourse?Values=", _Array);
                Result<List<SE_Course>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Course>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CategoryId),
                                 Convert.ToString(c.CategoryDesc),
                                 Convert.ToString(c.Title),
                                 Convert.ToString(c.Desc)
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateCourse(SE_Course _Course)
        {
            try
            {
                //Server-Side Validation
                if (_Course.btnType == "Save")
                {
                    if (Sanitizer.GetSafeHtmlFragment(_Course.CategoryId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Course.CategoryId.ToString()), @"^[0-9]+$") == false)
                        return Json(new Result(false, 500, "Validation Error", "Please Select Category"), JsonRequestBehavior.AllowGet);
                    if (Sanitizer.GetSafeHtmlFragment(_Course.Title) == null || Sanitizer.GetSafeHtmlFragment(_Course.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Course.Title).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Course.Title).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Title should not be Empty and must contain Min of 2 & Max of 50 characters"), JsonRequestBehavior.AllowGet);
                    if (Sanitizer.GetSafeHtmlFragment(_Course.Desc) == null || Sanitizer.GetSafeHtmlFragment(_Course.Desc) == "" || Sanitizer.GetSafeHtmlFragment(_Course.Desc).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain Min of 2 characters"), JsonRequestBehavior.AllowGet);
                }
                else if (_Course.btnType == "Update")
                {
                    if (Sanitizer.GetSafeHtmlFragment(_Course.Desc) == null || Sanitizer.GetSafeHtmlFragment(_Course.Desc) == "" || Sanitizer.GetSafeHtmlFragment(_Course.Desc).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain Min of 2 characters"), JsonRequestBehavior.AllowGet);
                }

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_Course.CategoryId.ToString()));
                _Array.Add(RSAPattern.Encrypt(_Course.Title));
                _Array.Add(RSAPattern.Encrypt(_Course.Desc));
                _Array.Add(RSAPattern.Encrypt(_Course.btnType));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCreateCourse?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourse(string Title)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(Title));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourse?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CourseDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetCourseDetails()
        {
            List<SE_CourseDetails> _list = new List<SE_CourseDetails>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourseDetails?Values=", _Array);
                Result<List<SE_CourseDetails>> _Result = JsonConvert.DeserializeObject<Result<List<SE_CourseDetails>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.CDetailsId),
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CourseTitle),
                                 Convert.ToString(c.CategoryId),
                                 Convert.ToString(c.CategoryDesc),
                                 Convert.ToString(c.Currency),
                                 Convert.ToString(c.Price),
                                 Convert.ToString(c.Rating),
                                 Convert.ToString(c.Duration),
                                 Convert.ToString(c.NumOfClasses),
                                 Convert.ToString(c.Image),
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult AddCourseDetails()
        {
            SE_CourseDetails model = new SE_CourseDetails();
            try
            {
                ViewBag.Course_dll = Reusable.CourseList(); // All Courses
                ViewBag.Caption = "Add Record";
                ViewBag.Button = "Save";
                return View("../PartialViews/AddCourseDetailsSideBar", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateCourseDetails(SE_CourseDetails _CDetails)
        {
            try
            {
                //Server-Side Validation
                if (Sanitizer.GetSafeHtmlFragment(_CDetails.CourseId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.CourseId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Course"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Currency == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Currency) == "" || Sanitizer.GetSafeHtmlFragment(_CDetails.Currency).Length > 20)
                    return Json(new Result(false, 500, "Validation Error", "Currency should not be Empty and must contain Max of 20 characters"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Price == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Price) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.Price), @"^((\d+(\\.\d{0,2})?)|((\d*(\.\d{1,2}))))$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.Rating).Length > 10)
                    return Json(new Result(false, 500, "Validation Error", "Price should not be Empty and must contain Max of 10 digits"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Rating == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Rating) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.Rating), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.Rating).Length > 1)
                    return Json(new Result(false, 500, "Validation Error", "Rating should not be Empty and must contain only 1 digit"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Duration == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Duration) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.Duration), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.Duration).Length > 5)
                    return Json(new Result(false, 500, "Validation Error", "Duration should not be Empty and must must contain Max of 5 digits"), JsonRequestBehavior.AllowGet);
                if (_CDetails.NumOfClasses == null || Sanitizer.GetSafeHtmlFragment(_CDetails.NumOfClasses) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.NumOfClasses), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.NumOfClasses).Length > 5)
                    return Json(new Result(false, 500, "Validation Error", "Num Of Classes should not be Empty and must contain Max of 5 digits"), JsonRequestBehavior.AllowGet);

                if (_CDetails.btnType == "Save")
                {
                    if (_CDetails.Image != null)
                    {
                        List<string> _ext = Reusable.ProfilePicExtentions();
                        if (!_ext.Contains(_CDetails.ImgType))
                            return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(new Result(false, 500, "Validation Error", "Upload a Images"), JsonRequestBehavior.AllowGet);
                }
                else if (_CDetails.btnType == "Update")
                {
                    if (_CDetails.Image != null)
                    {
                        List<string> _ext = Reusable.ProfilePicExtentions();
                        if (!_ext.Contains(_CDetails.ImgType))
                            return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                    }
                }
                else
                    return Json(new Result(false, 500, "Validation Error", "Internal Server Error"), JsonRequestBehavior.AllowGet);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_CDetails.CourseId.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Currency.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Price.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Rating.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Duration.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.NumOfClasses.ToString()));
                _Array.Add(_CDetails.Image);
                _Array.Add(_CDetails.CDetailsId);
                _Array.Add(RSAPattern.Encrypt(_CDetails.btnType));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCourseDetails?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult EditCourseDetails(int id)
        {
            SE_CourseDetails model = new SE_CourseDetails();
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(id.ToString()));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/EditCourseDetails?Values=", _Array);
                Result<SE_CourseDetails> _Result = JsonConvert.DeserializeObject<Result<SE_CourseDetails>>(response);

                if (_Result.Status)
                {
                    model.CDetailsId = _Result.Data.CDetailsId;
                    model.CourseId = _Result.Data.CourseId;
                    ViewBag.Course_dll = Reusable.CourseList(); // All Courses
                    model.CourseTitle = _Result.Data.CourseTitle;
                    model.CategoryId = _Result.Data.CategoryId;
                    model.CategoryDesc = _Result.Data.CategoryDesc;
                    model.Currency = _Result.Data.Currency;
                    model.Price = _Result.Data.Price;
                    model.Rating = _Result.Data.Rating;
                    model.Duration = _Result.Data.Duration;
                    model.NumOfClasses = _Result.Data.NumOfClasses;
                    model.Image = _Result.Data.Image;
                }

                ViewBag.PKId = RSAPattern.Encrypt(_Result.Data.CDetailsId.ToString());
                ViewBag.Caption = "Edit Record";
                ViewBag.Button = "Update";
                return View("../PartialViews/AddCourseDetailsSideBar", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourseDetails(string ID)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(ID));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourseDetails?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CourseContent()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.CCoCourse_dll = Reusable.CourseList(); // All Courses
            return View();
        }

        public JsonResult GetCourseContent()
        {
            List<SE_CourseContent> _list = new List<SE_CourseContent>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourseContent?Values=", _Array);
                Result<List<SE_CourseContent>> _Result = JsonConvert.DeserializeObject<Result<List<SE_CourseContent>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.ContentId),
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CourseDesc),
                                 Convert.ToString(c.Content),
                                 Convert.ToString(GetShortData(c.Content))
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        private string GetShortData(string _Data)
        {
            string StripHtml = Regex.Replace(_Data, "<.*?>|&.*?;", string.Empty);
            StripHtml = StripHtml.ToString().Length > 30 ? StripHtml.ToString().Substring(0, 30) + "...." : StripHtml.ToString();
            return StripHtml;
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateCourseContent(SE_CourseContent _CContent)
        {
            try
            {
                //Server-Side Validation
                if (Sanitizer.GetSafeHtmlFragment(_CContent.CourseId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CContent.CourseId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Course"), JsonRequestBehavior.AllowGet);
                if (_CContent.Content == null || Sanitizer.GetSafeHtmlFragment(_CContent.Content) == "")
                    return Json(new Result(false, 500, "Validation Error", "Content should not be Empty"), JsonRequestBehavior.AllowGet);

                if (_CContent.btnType == "Update")
                {
                    if (_CContent.ContentId == null || Sanitizer.GetSafeHtmlFragment(_CContent.ContentId) == "")
                        return Json(new Result(false, 500, "Validation Error", "ContentId should not be Empty"), JsonRequestBehavior.AllowGet);
                }

                //API Call		
                ArrayList _Array = new ArrayList();
                if (_CContent.btnType == "Update")
                    _Array.Add(RSAPattern.Encrypt(_CContent.ContentId.ToString()));
                else
                    _Array.Add(_CContent.ContentId);
                _Array.Add(RSAPattern.Encrypt(_CContent.CourseId.ToString()));
                _Array.Add(_CContent.Content.ToString());
                _Array.Add(RSAPattern.Encrypt(_CContent.btnType.ToString()));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCourseContent?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourseContent(string ID)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(ID));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourseContent?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CreateBatch()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.Course_dll = Reusable.CourseList(); // All Courses
            ViewBag.Students_dll = Reusable.StudentsList(); // All Courses
            return View();
        }

        public ActionResult BatchDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.Batch_dll = Reusable.CourseList(); // All Courses
            ViewBag.Students_dll = Reusable.StudentsList(); // All Courses
            return View();
        }

        public ActionResult ContactUsForm()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
    }
}