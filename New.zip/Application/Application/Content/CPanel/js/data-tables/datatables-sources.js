$(document).ready(function () {

    $('.GetStudentDetails').on("click", ".editStudentDetails", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        $.get(url, function (data) {
            $('#CreateSDData').html(data);
            $('.notification-sidebar').toggleClass('open');
        });
    });

    $('.GetStudentDetails').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetStudentDetails',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter UserId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "20%", "sClass": "TextCenter FullName", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "20%", "sClass": "TextCenter Email", "render": function (data, type, row) { return (row[4]); } },
            { "sWidth": "20%", "sClass": "TextCenter Mobile", "render": function (data, type, row) { return (row[5]); } },
            { "sWidth": "10%", "sClass": "TextCenter Role", "render": function (data, type, row) { return (row[6]); } },
            { "sWidth": "10%", "sClass": "TextCenter IsActive", "render": function (data, type, row) { return (row[7]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="/CPanelAdmin/EditStudentDetails?id=' + row[0] + '"  class="editStudentDetails notification-sidebar-toggle" title="Edit" return false;> <i class="fa fa-edit"></i></a>&nbsp;&nbsp;</center>';
                }, "targets": 0,
            }
        ],
    });
});