﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an option.");


$(document).ready(function () {

    GetTable();

    $('#ViewContentModel').modal('hide');

    $('#btnSaveDetails').val("Save");

    $("#CreateCourseContent").validate({
        rules: {
            'CCoCourseId': {
                selectNone: true
            },
            'CCoContent': {
                required: true
            }
        },
        messages: {
            'CCoCourseId': {
                selectNone: 'Please Select Course'
            },
            'CCoContent': {
                required: 'Enter Content'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                var _postData = {
                    ContentId: $('#CoID').val(),
                    CourseId: $('#CCoCourseId').val(),
                    Content: $('#CCoContent').val(),
                    btnType: $('#btnSaveDetails').val()
                };
                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/InsertUpdateCourseContent",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    GetTable();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
    $("#btnCancel").click(function () {
        ClearFields();
    });
});

function GetTable() {
    Table = $('.GetCourseContent').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetCourseContent',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "sWidth": "10%", "sClass": "TextCenter ContentId DisapbelDTColumn", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "20%", "sClass": "TextCenter CourseId DisapbelDTColumn", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "20%", "sClass": "TextCenter CourseDesc", "render": function (data, type, row) { return (row[2]); } },
            { "sWidth": "20%", "sClass": "TextCenter Content DisapbelDTColumn", "render": function (data, type, row) { return (row[3]); } },
            {
                "sWidth": "20%", "sClass": "TextCenter ContentShort",
                "render": function (data, type, row) {
                    return '<span title="Click On View to Read More Data">' + row[4] + ' </span>';;
                }
            },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" onclick=ViewData(this); class="viewCourseContent" title="View" return false;> <i class="fa fa-eye"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" title="Delete"  onclick=DeleteData("' + row[0] + '"); return false;> <i class="fa fa-trash-o"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function ViewData(row) {
    var CourseDesc = $(row).closest('tr').find('.CourseDesc').html();
    $('#CourseTitle').html(CourseDesc);

    var Content = $(row).closest('tr').find('.Content').html();
    $('#ViewContentModel').modal('show');
    $('#ViewContentData').html(Content);
}

//function EditData(row) {
//    var ContentId = $(row).closest('tr').find('.ContentId').html();
//    $('#CoID').val(ContentId);

//    var CourseId = $(row).closest('tr').find('.CourseId').html();
//    $('#CCoCourseId').val(CourseId);

//    var Content = $(row).closest('tr').find('.Content').html();
//    $('#CCoContent').val(Content);

//    $('#CCoCourseId').attr('disabled', true);
//    $('#btnSaveDetails').val("Update");
//}

function DeleteData(code) {
    swal({
        title: "Are you sure?",
        text: "This will delete the Record",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, Delete it!",
        closeOnConfirm: false
    },
        function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: '/CPanelAdmin/DeleteCourseContent',
                    type: 'POST',
                    data: JSON.stringify({ "ID": code }),
                    contentType: 'application/json; charset=utf-8;',
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");
                    }
                });
            }
        }
    );
}

function ClearFields() {
    $("#CCoCourseId").val('0');
    $("#CCoContent").html('');
    $('#CCoCourseId').attr('disabled', false);
    $('#btnSaveDetails').val("Save");
}