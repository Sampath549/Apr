﻿$(document).ready(function () {
    GetTable();

    $('#btnAddCourseDetails').on("click", function (event) {
        event.preventDefault();
        var url = '/CPanelAdmin/AddCourseDetails';
        $.get(url, function (data) {
            $('#CreateCDData').html(data);
            $('.notification-sidebar').toggleClass('open');
        });
    });

    $('.GetCourseDetails').on("click", ".editCourseDetails", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        $.get(url, function (data) {
            $('#CreateCDData').html(data);
            $('.notification-sidebar').toggleClass('open');
        });
    });
});

function GetTable(event) {
    Table = $('.GetCourseDetails').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetCourseDetails',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter CDetailsId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "15%", "sClass": "TextCenter Category", "render": function (data, type, row) { return (row[4]); } },
            { "sClass": "TextCenter Course", "render": function (data, type, row) { return (row[2]); } },
            { "sWidth": "8%", "sClass": "TextCenter Currency", "render": function (data, type, row) { return (row[5]); } },
            { "sWidth": "6%", "sClass": "TextCenter Price", "render": function (data, type, row) { return (row[6]); } },
            { "sWidth": "8%", "sClass": "TextCenter Ratting", "render": function (data, type, row) { return (row[7]); } },
            { "sWidth": "8%", "sClass": "TextCenter Duration", "render": function (data, type, row) { return (row[8]); } },
            { "sWidth": "10%", "sClass": "TextCenter NumOfClasses", "render": function (data, type, row) { return (row[9]); } },
            { "sWidth": "0%", "sClass": "TextCenter Image DisapbelDTColumn", "render": function (data, type, row) { return (row[10]); } },
            {
                "sWidth": "6%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="/CPanelAdmin/EditCourseDetails?id=' + row[0] + '" class="editCourseDetails notification-sidebar-toggle" title="Edit" return false;> <i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" title="Delete"  onclick=DeleteData("' + row[0] + '"); return false;> <i class="fa fa-trash-o"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function DeleteData(code) {
    swal({
        title: "Are you sure?",
        text: "This will delete the Record",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, Delete it!",
        closeOnConfirm: false
    },
        function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: '/CPanelAdmin/DeleteCourseDetails',
                    type: 'POST',
                    data: JSON.stringify({ "ID": code }),
                    contentType: 'application/json; charset=utf-8;',
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");
                    }
                });
            }
        }
    );
}
