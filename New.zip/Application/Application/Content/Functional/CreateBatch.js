﻿$(document).ready(function () {
    $("#CreateBatch").validate({    
        rules: {
            'CourseID': {
                selectNone: true
            }
        },
        messages: {
            'CourseID': {
                selectNone: 'Please Select Course'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                alert(1);
                //var _postData = {
                //    CategoryId: $('#CCID').val(),
                //    Title: $('#CTitle').val(),
                //    Desc: $('#CDesc').val(),
                //    btnType: $('#btnSaveDetails').val()
                //};

                //$.ajax({
                //    type: "POST",
                //    url: "/CPanelAdmin/CreateCourse",
                //    data: _postData,
                //    dataType: "json",
                //    cache: false,
                //    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                //    success: function (response) {
                //        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                //        if (!response.Status)
                //            toastr.error(response.Message, response.Caption, opts);
                //        else {
                //            swal({
                //                title: "Success!",
                //                text: response.Message,
                //                type: "success",
                //                confirmButtonText: "OK"
                //            },
                //            function (isConfirm) {
                //                if (isConfirm) {
                //                    ClearFields();
                //                    GetTable();
                //                }
                //            });
                //        }
                //        $(".loadingImg").hide();
                //    },
                //    error: function (xhr, ajaxOptions, thrownError) {
                //        alert(xhr.responseText);
                //    }
                //});
            }, 0);
        }
    });
    //$("#btnCancel").click(function () {
    //    ClearFields();
    //});
});

//function ClearFields() {
//    $("#CTitle").val('');
//    $("#CDesc").val('');
//    $("#CCID").val('0');
//    $('#CTitle').attr('disabled', false);
//    $('#CCID').attr('disabled', false);
//    $('#btnSaveDetails').val("Save");
//}