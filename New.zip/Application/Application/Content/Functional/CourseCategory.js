﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

$(document).ready(function () {

    GetTable();

    $('#btnSaveDetails').val("Save");

    $("#CreateCourseCategory").validate({
        rules: {
            'CCCode': {
                required: true,
                minlength: 2,
                maxlength: 5,
                lettersonly: true
            },
            'CCDesc': {
                required: true,
                maxlength: 30
            }
        },
        messages: {
            'CCCode': {
                required: 'Enter Code',
                minlength: 'Must enter Minimum of 2 characters',
                maxlength: 'Must enter Maximum of 5 characters'
            },
            'CCDesc': {
                required: 'Enter Description',
                maxlength: 'Must enter Maximum of 30 characters'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {
                var _postData = {
                    Code: $('#CCCode').val(),
                    Description: $('#CCDesc').val(),
                    ButtonType: $('#btnSaveDetails').val()
                };
                console.log(_postData);
                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/InsertUpdateCourseCategory",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    GetTable();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
    $("#btnCancel").click(function () {
        ClearFields();
    });
});

function GetTable() {
    Table = $('.GetCourseCategory').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetCourseCategory',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter CategoryId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "20%", "sClass": "TextCenter Code", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "20%", "sClass": "TextCenter Description", "render": function (data, type, row) { return (row[2]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" onclick=EditCCategoryData(this); class="editCourseCategory" title="Edit" return false;> <i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" title="Delete"  onclick=DeleteCCategoryData("' + row[1] + '"); return false;> <i class="fa fa-trash-o"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function EditCCategoryData(row) {
    var Code = $(row).closest('tr').find('.Code').html();
    $('#CCCode').val(Code);

    var Desc = $(row).closest('tr').find('.Description').html();
    $('#CCDesc').val(Desc);

    $('#CCCode').attr('disabled', true);
    $('#btnSaveDetails').val("Update");
}

function DeleteCCategoryData(code) {
    swal({
        title: "Are you sure?",
        text: "This will delete the Record",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, Delete it!",
        closeOnConfirm: false
    },
        function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: '/CPanelAdmin/DeleteCourseCategory',
                    type: 'POST',
                    data: JSON.stringify({ "Code": code }),
                    contentType: 'application/json; charset=utf-8;',
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");
                    }
                });
            }
        }
    );
}

function ClearFields() {
    $("#CCCode").val('');
    $("#CCDesc").val('');
    $('#CCCode').attr('disabled', false);
    $('#btnSaveDetails').val("Save");
}