﻿$(document).ready(function () {

    $(function () {
        $('#BDlist').multiselect({
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            filterPlaceholder: 'Search for Students...'
        });
    });
});