﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {
    var input = $('.inputVal');
    $('#btnLogin').click(function (event) {
        event.preventDefault();
        $(".loadingImg").show();

        var response = grecaptcha.getResponse();
        var check = true;

        for (var i = 0; i < input.length; i++) {
            if (validate(input[i]) == false) {
                check = false;
            }
        }

        if (check) {
            $.ajax({
                type: "POST",
                url: "/CPanel/LoginAuthentication",
                data: { _User: $('#Email').val(), _Password: $('#Password').val(), _ReCaptcha: response },
                dataType: "json",
                cache: false,
                headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                success: function (response) {
                    $(".loadingImg").hide();
                    if (!response.Data.Status)
                        toastr.error(response.Message, response.Caption, opts);
                    else
                        window.location.href = response.Data.RedirectUrl;
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    toastr.error(response.Message, "Something Went Wrong", opts);
                }
            });
        }
        else
            return check;
    });
});

function validate(input) {
    if ($(input).attr('name') == 'Email') {
        if ($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
            if ($("#Email").val() != '')
                toastr.error("Enter a Valid Email", opts);
            else
                toastr.error("Please Enter Email", opts);
            return false;
        }
    }

    if ($(input).attr('name') == 'Password') {
        if ($(input).val().trim() == '') {
            toastr.error("Please Enter Password", opts);
            return false;
        }
    }
}