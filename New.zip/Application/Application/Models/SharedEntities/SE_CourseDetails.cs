﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Models.SharedEntities
{
    public class SE_CourseDetails
    {
        public string CDetailsId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryDesc { get; set; }
        public int CourseId { get; set; }
        public string CourseTitle { get; set; }
        public string Currency { get; set; }
        public string Price { get; set; }
        public string Rating { get; set; }
        public string Duration { get; set; }
        public string NumOfClasses { get; set; }
        public string Image { get; set; }
        public string ImgType { get; set; }
        public string FileSize { get; set; }
        public string btnType{ get; set; }
    }
}