﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Course
    {
        public int CourseId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryDesc { get; set; }
        public string Title { get; set; }
        public string Desc { get; set; }
        public string btnType { get; set; }
    }
}