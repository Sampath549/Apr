﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Models.SharedEntities
{
    public class SE_CourseContent
    {
        public string ContentId { get; set; }
        public int CourseId { get; set; }
        public string CourseDesc { get; set; }
        [AllowHtml]
        public string Content { get; set; }
        [AllowHtml]
        public string ContentShort { get; set; }
        public string btnType { get; set; }
    }
}