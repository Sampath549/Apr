﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Users
    {
        public int Status { get; set; }
        public int UserId { get; set; }
        public string PersonalKey { get; set; }
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string SaltKey { get; set; }
        public string Gender { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string StateId { get; set; }
        public string StateCode { get; set; }
        public string StateDesc { get; set; }
        public string CountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryDesc { get; set; }
        public string ZipCode { get; set; }
        public string RoleCode { get; set; }
        public string RoleDesc { get; set; }
        public string RoleIdVal { get; set; }
        public int RoleId { get; set; }
        public bool IsActive { get; set; }
        public string ProfilePic { get; set; }
        public bool IsFirstTimeLogin { get; set; }
        public string GRecaptchaResponse { get; set; }
        public string RedirectUrl { get; set; }
    }
}