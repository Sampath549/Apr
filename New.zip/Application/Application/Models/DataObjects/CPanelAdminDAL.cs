﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelAdminDAL : DataAccessComponent
    {
        public List<SE_Users> GetStudentDetails()
        {
            try
            {
                List<SE_Users> _Rec = new List<SE_Users>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT
                                                U.UserId, 
	                                            U.FirstName +' '+ U.LastName [FullName],
	                                            U.FirstName,
	                                            U.LastName, 
	                                            U.Email,
	                                            U.Mobile,
	                                            U.RoleId,
	                                            R.Description [RoleDesc],
	                                            U.IsActive
                                            FROM [tbl_Users] U 
                                            INNER JOIN [Ref_Roles] R ON R.RoleId = U.RoleId 
                                            WHERE U.RoleId = @RoleId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@RoleId", GlobalVariables.Shared.StudentRoleId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Users { UserId = Convert.ToInt32(dr["UserId"]), FirstName = Convert.ToString(dr["FirstName"]), LastName = dr["LastName"].ToString(), Email = dr["Email"].ToString(), Mobile = dr["Mobile"].ToString(), RoleId = Convert.ToInt32(dr["RoleId"]), RoleDesc = dr["RoleDesc"].ToString(), IsActive = Convert.ToBoolean(dr["IsActive"]) });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public List<SE_Users> EditStudentDetails(int UID)
        {
            try
            {
                List<SE_Users> _Rec = new List<SE_Users>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT
                                                U.UserId, 
	                                            U.FirstName +' '+ U.LastName [FullName],
	                                            U.FirstName,
	                                            U.LastName, 
	                                            U.Email,
	                                            U.Mobile,
	                                            U.RoleId,
	                                            R.Description [RoleDesc],
	                                            U.IsActive
                                            FROM [tbl_Users] U 
                                            INNER JOIN [Ref_Roles] R ON R.RoleId = U.RoleId 
                                            WHERE U.RoleId = @RoleId AND U.UserId = @UserId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@RoleId", GlobalVariables.Shared.StudentRoleId);
                        da.SelectCommand.Parameters.AddWithValue("@UserId", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Users { UserId = Convert.ToInt32(dr["UserId"]), FirstName = Convert.ToString(dr["FirstName"]), LastName = dr["LastName"].ToString(), Email = dr["Email"].ToString(), Mobile = dr["Mobile"].ToString(), RoleId = Convert.ToInt32(dr["RoleId"]), RoleDesc = dr["RoleDesc"].ToString(), IsActive = Convert.ToBoolean(dr["IsActive"]) });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int UpdateStudentDetails(SE_Users Users)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Update_StudentDetails";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = Users.UserId;
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = Users.FirstName;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = Users.LastName;
                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = Users.IsActive;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_RefValues> GetCourseCategory()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [tbl_CourseCategory]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CategoryId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCourseCategory(string Code, string Desc, string btnType)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CourseCategory";
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = Desc;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteCourseCategory(string Code)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_CourseCategory";
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_RefValues> CourseCategoryList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT [CategoryId], [Description] FROM [tbl_CourseCategory]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CategoryId"]), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public List<SE_Course> GetCourse()
        {
            try
            {
                List<SE_Course> _Rec = new List<SE_Course>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT C.CourseId, C.CategoryId,CC.[Description] [CategoryDesc], C.Title, C.[Description] FROM [tbl_Course] C INNER JOIN[tbl_CourseCategory] CC ON CC.CategoryId = C.CategoryId ", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Course { CourseId = Convert.ToInt32(dr["CourseId"]), CategoryId = Convert.ToInt32(dr["CategoryId"]), CategoryDesc = dr["CategoryDesc"].ToString(), Title = dr["Title"].ToString(), Desc = dr["Description"].ToString() });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCreateCourse(SE_Course _Course)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CreateCourse";
                cmd.Parameters.Add("@CategoryId", SqlDbType.Int).Value = _Course.CategoryId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _Course.Title;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = _Course.Desc;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = _Course.btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteCourse(string Title)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_Delete_Course";
            cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = Title;

            SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            cmd.Parameters.Add(outputIdParam);
            cmd.Connection = con;

            try
            {
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                string str = ex.Message;
                if (str.IndexOf("The DELETE statement conflicted with the REFERENCE constraint") > -1)
                {
                    throw new Exception("Related Records");
                }
                else
                    throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_CourseDetails> GetCourseDetails()
        {
            try
            {
                List<SE_CourseDetails> _Rec = new List<SE_CourseDetails>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_CourseDetails", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_CourseDetails
                        {
                            CDetailsId = Convert.ToString(dr["CDetailsId"]),
                            CourseId = Convert.ToInt32(dr["CourseId"]),
                            CourseTitle = Convert.ToString(dr["CourseTitle"]),
                            CategoryId = Convert.ToInt32(dr["CategoryId"]),
                            CategoryDesc = dr["CategoryDesc"].ToString(),
                            Currency = dr["Currency"].ToString(),
                            Price = dr["Price"].ToString(),
                            Rating = dr["Ratting"].ToString(),
                            Duration = dr["Duration"].ToString(),
                            NumOfClasses = dr["NumOfClasses"].ToString(),
                            Image = dr["Image"].ToString()
                        });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> CourseList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT [CourseId], [Title] FROM [tbl_Course]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CourseId"]), Description = dr["Title"].ToString() });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCourseDetails(string CourseId, string Currency, string Price, string Rating, string Duration, string NumOfClasses, string Image, string CDetailsId, string btnType)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CourseDetails";
                cmd.Parameters.Add("@CourseId", SqlDbType.VarChar).Value = Convert.ToInt32(CourseId);
                cmd.Parameters.Add("@Currency", SqlDbType.VarChar).Value = Currency;
                cmd.Parameters.Add("@Price", SqlDbType.Decimal).Value = Convert.ToDecimal(Price);
                cmd.Parameters.Add("@Rating", SqlDbType.Int).Value = Convert.ToInt32(Rating);
                cmd.Parameters.Add("@Duration", SqlDbType.Int).Value = Convert.ToInt32(Duration);
                cmd.Parameters.Add("@NumOfClasses", SqlDbType.Int).Value = Convert.ToInt32(NumOfClasses);
                cmd.Parameters.Add("@Image", SqlDbType.VarChar).Value = Image;
                cmd.Parameters.Add("@CDetailsId", SqlDbType.Int).Value = Convert.ToInt32(CDetailsId);
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_CourseDetails> EditCourseDetails(int CDID)
        {
            try
            {
                List<SE_CourseDetails> _Rec = new List<SE_CourseDetails>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_CourseDetailsById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@CDetailsId", CDID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_CourseDetails
                        {
                            CDetailsId = Convert.ToString(dr["CDetailsId"]),
                            CourseId = Convert.ToInt32(dr["CourseId"]),
                            CourseTitle = Convert.ToString(dr["CourseTitle"]),
                            CategoryId = Convert.ToInt32(dr["CategoryId"]),
                            CategoryDesc = dr["CategoryDesc"].ToString(),
                            Currency = dr["Currency"].ToString(),
                            Price = dr["Price"].ToString(),
                            Rating = dr["Ratting"].ToString(),
                            Duration = dr["Duration"].ToString(),
                            NumOfClasses = dr["NumOfClasses"].ToString(),
                            Image = dr["Image"].ToString()
                        });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int DeleteCourseDetails(string ID)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_CourseDetails";
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_CourseContent> GetCourseContent()
        {
            try
            {
                List<SE_CourseContent> _Rec = new List<SE_CourseContent>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT CCo.ContentId, CCo.CourseId, C.[Title] [CourseDesc], CCo.Concepts [Content] FROM [tbl_CourseContent] CCo INNER JOIN [tbl_Course] C ON C.CourseId = CCo.CourseId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_CourseContent { ContentId = Convert.ToString(dr["ContentId"]), CourseId = Convert.ToInt32(dr["CourseId"]), CourseDesc = dr["CourseDesc"].ToString(), Content = dr["Content"].ToString(), ContentShort = dr["Content"].ToString().Length > 30 ? dr["Content"].ToString().Substring(0, 30) + "...." : dr["Content"].ToString() });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCourseContent(string ContentId, string CourseId, string Content, string btnType)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CourseContent";
                if (btnType == "Update")
                    cmd.Parameters.Add("@ContentId", SqlDbType.Int).Value = Convert.ToInt32(ContentId);
                else if (btnType == "Save")
                    cmd.Parameters.Add("@ContentId", SqlDbType.Int).Value = null;
                cmd.Parameters.Add("@CourseId", SqlDbType.Int).Value = Convert.ToInt32(CourseId);
                cmd.Parameters.Add("@Content", SqlDbType.VarChar).Value = Content;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteCourseContent(string ID)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_CourseContent";
                cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = ID;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public List<SE_RefValues> StudentsList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT UserId, FirstName, LastName, Email FROM tbl_Users WHERE IsActive = 1 AND RoleId = @RoleId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@RoleId", GlobalVariables.Shared.StudentRoleId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        string FullVal = AES_Algorithm.DecryptString(dr["FirstName"].ToString()) + " " + AES_Algorithm.DecryptString(dr["LastName"].ToString()) + " (" + StringEncrypt.Decrypt(dr["Email"].ToString()) + ")";
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["UserId"]), Description = FullVal });
                    }

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
    }
}