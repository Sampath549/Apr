USE [StepTek]

IF OBJECT_ID (N'[Ref_Roles]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Roles]

CREATE TABLE [Ref_Roles]
(
[RoleId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE()
CONSTRAINT PK_RefRoleId PRIMARY KEY ([RoleId]),
CONSTRAINT UC_RefRoleCode UNIQUE ([Code])
)

INSERT [Ref_Roles] ([Code], [Description]) VALUES ('DEV', 'Developer')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('ADM', 'Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('STU', 'Student')

SELECT * FROM [Ref_Roles]  

----- END -----

IF OBJECT_ID (N'[tbl_Users]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Users]

CREATE TABLE [tbl_Users]
(
[UserId]				INT					NOT NULL IDENTITY(1,1),
[PersonalKey]			VARCHAR(800)		NOT NULL,
[FirstName]				VARCHAR(800)		NOT NULL,
[LastName]				VARCHAR(800)		NOT NULL,
[RoleId]				INT					NOT NULL,
[Password]				VARCHAR(800)		NOT NULL,
[SaltKey]				VARCHAR(800)		NOT NULL,
[Email]					VARCHAR(800)		NOT NULL,
[Mobile]				VARCHAR(800)		NOT NULL,
[Photo]					VARCHAR(MAX)		NULL,
[ImgType]				VARCHAR(800)		NULL,
[Gender]				VARCHAR(300)		NULL,
[IsFirstTimeLogin]		BIT					DEFAULT 1,
[IsActive]				BIT					DEFAULT 1,
[CreatedDate]			DATETIME			DEFAULT GETDATE()
CONSTRAINT PK_tblUserId PRIMARY KEY ([UserId]),
CONSTRAINT UC_UserEmail UNIQUE ([Email]),
CONSTRAINT UC_UserMobile UNIQUE ([Mobile])
)

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[Email],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedDate]) 
VALUES 
(
'/y8jscTrl55uuy0F8XSXw753DtKQ+00tdRDjan53rftd3IxTYnBOfmseHjWCiKpd/nRhhcr+IQHv0NummGslgg==',
'y9pCWYBIqA57uOf1ac5sJxZxer8oXmYnXPlGb8YP/f0=', 
'jJvUC6EubMYdWKSMV8J03wtOeyq4Uj5JOF7jfxfWl9I=', 
1,
'Nky5VhXfD6T9ZLaUWTO5BNeu+rMdVMz4X96RSeKh7mg=', 
'7SqpTsUktXWRoxWaEQFHHZBci/h7x4l2beOi2upTbls=', 
'GLlFWpU4PZsR+jb7S1PkGyvwFX9EHwCBLkie7NeA9o8=', 
'4yb8Cu1EVg5mb8uzxMTvIw==',
1,1,GETDATE()
)
---- Actual Values
--FirstName - Sampath
--LastName - Bandari
--Email - sampath.bandari51@gmail.com
--Mobile - 8121839354
--Password - Step@123
--Salt - 1S4:q|F5

SELECT * FROM [tbl_Users]

----- END -----

IF OBJECT_ID (N'[Ref_Countries]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Countries]

CREATE TABLE [Ref_Countries]
(
[CountryId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_CountryId PRIMARY KEY ([CountryId]),
CONSTRAINT UC_CountryCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_Countries] ([Code], [Description]) VALUES ('GER', 'Germany')

SELECT * FROM [Ref_Countries]  

----- END -----

IF OBJECT_ID (N'[Ref_States]', N'U') IS NOT NULL 
   DROP TABLE [Ref_States]

CREATE TABLE [Ref_States]
(
[StateId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CountryId]		INT				NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_StateId PRIMARY KEY ([StateId]),
CONSTRAINT FK_CState FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_StateCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('HAM', 'Hamburg', 1)

SELECT * FROM [Ref_States]  

----- END -----

IF OBJECT_ID (N'[tbl_UserMapping]', N'U') IS NOT NULL 
   DROP TABLE [tbl_UserMapping]

CREATE TABLE [tbl_UserMapping]
(
[UserId]					INT				NOT NULL,
[IsPermanentAddress]		BIT				NULL,
[PermanentStreetAddress]	VARCHAR(MAX)	NULL,
[PermanentCity]				VARCHAR(800)	NULL,
[PermanentState]			INT				NULL,
[PermanentCountry]			INT				NULL,
[PermanentZipCode]			BIGINT			NULL,
[CurrentStreetAddress]		VARCHAR(MAX)	NULL,
[CurrentCity]				VARCHAR(800)	NULL,
[CurrentState]				INT				NULL,
[CurrentCountry]			INT				NULL,
[CurrentZipCode]			BIGINT			NULL,
CONSTRAINT FK_UMUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_UMPState FOREIGN KEY ([PermanentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMPCountry FOREIGN KEY ([PermanentCountry]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT FK_UMCState FOREIGN KEY ([CurrentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMCCountry FOREIGN KEY ([CurrentCountry]) REFERENCES [Ref_Countries]([CountryId])
)

SELECT * FROM [tbl_UserMapping]  

----- END -----

IF OBJECT_ID (N'[tbl_ResetPwdLog]', N'U') IS NOT NULL 
   DROP TABLE [tbl_ResetPwdLog]

CREATE TABLE [tbl_ResetPwdLog]
(
[ResetPwdLogId]		INT				NOT NULL IDENTITY(1,1),
[UserId]			INT				NOT NULL,
[GuidVal]			VARCHAR(800)	NOT NULL,
[IsReset]			BIT				NOT NULL,
[EntryDate]			DATETIME		NOT NULL
CONSTRAINT PK_ResetPwdLogId PRIMARY KEY ([ResetPwdLogId]),
CONSTRAINT FK_RPwdUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_ResetPwdLog]

----- END -----

IF OBJECT_ID (N'[tbl_Menus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Menus]

CREATE TABLE [tbl_Menus]
(
[ParentId]		INT				NOT NULL IDENTITY(1,1),
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NULL,
[Action]		VARCHAR(50)		NULL,
[HavingChild]	BIT				NOT NULL,
[Order]			INT				NOT NULL,
[Icon]			VARCHAR(50)		NOT NULL,
CONSTRAINT PK_ParentId PRIMARY KEY ([ParentId]),
CONSTRAINT UC_PHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelDev', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('All Users', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Master Data', NULL, NULL, 1, 3, 'fa fa-star-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Error Log', 'CPanelDev', 'ViewErrorLog', 0, 4, 'fa fa-exclamation-triangle')

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelAdmin', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Students', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Upload Material', NULL, NULL, 1, 3, 'fa fa-book')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Courses', NULL, NULL, 1, 4, 'fa fa-clone')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Batches', NULL, NULL, 1, 5, 'fa fa-bars')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Contact Us Form', 'CPanelAdmin', 'ContactUsForm', 0, 6, 'fa fa-bell-o')

SELECT * FROM [tbl_Menus]  

----- END -----

IF OBJECT_ID (N'[tbl_SubMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_SubMenus]

CREATE TABLE [tbl_SubMenus]
(
[ChildId]		INT 			NOT NULL IDENTITY(1,1),
[ParentId]		INT				NOT NULL,
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NOT NULL,
[Action]		VARCHAR(50)		NOT NULL,
[Order]			INT				NOT NULL,
CONSTRAINT PK_ChildId PRIMARY KEY ([ChildId]),
CONSTRAINT FK_SMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT UC_CHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Create', 'CPanelDev', 'CreateAllUsers', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Details', 'CPanelDev', 'AllUserDetails', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Roles', 'CPanelDev', 'CreateRole', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Menus', 'CPanelDev', 'CreateMenus', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Sub Menus', 'CPanelDev', 'CreateSubMenus', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Assigned Menus', 'CPanelDev', 'CreateAssignedMenus', 4)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Countries', 'CPanelDev', 'CreateCountries', 5)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'States', 'CPanelDev', 'CreateStates', 6)

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (6, 'Request Forms', 'CPanelAdmin', 'RequestForms', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (6, 'Create Student', 'CPanelAdmin', 'CreateStudent', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (6, 'Student Details', 'CPanelAdmin', 'StudentDetails', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Documents', 'CPanelAdmin', 'UploadDocuments', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Videos', 'CPanelAdmin', 'UploadVideos', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (8, 'Course Category', 'CPanelAdmin', 'CourseCategory', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (8, 'Create Course', 'CPanelAdmin', 'CreateCourse', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (8, 'Course Details', 'CPanelAdmin', 'CourseDetails', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (8, 'Course Content', 'CPanelAdmin', 'CourseContent', 4)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (9, 'Create Batch', 'CPanelAdmin', 'CreateBatch', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (9, 'Batch Details', 'CPanelAdmin', 'BatchDetails', 2)

SELECT * FROM [tbl_SubMenus]

----- END -----

IF OBJECT_ID (N'[tbl_AssignMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_AssignMenus]

CREATE TABLE [tbl_AssignMenus]
(
[AssignMenuId]	INT 	NOT NULL IDENTITY(1,1),
[ParentId]		INT		NOT NULL,
[RoleId]		INT		NOT NULL,
CONSTRAINT PK_AssignMenuId PRIMARY KEY ([AssignMenuId]),
CONSTRAINT FK_AMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT FK_AMenusRoleId FOREIGN KEY ([RoleId]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT UC_AMenusParentRole UNIQUE ([ParentId],[RoleId])
)

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (1, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (2, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (3, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (4, 1)

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (5, 2)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (6, 2)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (7, 2)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (8, 2)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (9, 2)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (10, 2)

SELECT * FROM [tbl_AssignMenus]

----- END -----

IF OBJECT_ID (N'[tbl_CourseCategory]', N'U') IS NOT NULL 
   DROP TABLE [tbl_CourseCategory]

CREATE TABLE [tbl_CourseCategory]
(
[CategoryId]	INT 			NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(25)		NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_CategoryId PRIMARY KEY ([CategoryId]),
CONSTRAINT UC_CCategoryCode UNIQUE ([Code]),
CONSTRAINT UC_CCategoryDesc UNIQUE ([Description])
)

-------- END --------

IF OBJECT_ID (N'[tbl_Course]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Course]

CREATE TABLE [tbl_Course]
(
[CourseId]		INT 			NOT NULL IDENTITY(1,1),
[CategoryId]	INT				NOT NULL,
[Title]			VARCHAR(50)		NOT NULL,
[Description]	VARCHAR(MAX)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_CourseId PRIMARY KEY ([CourseId]),
CONSTRAINT FK_CourseCCategory FOREIGN KEY ([CategoryId]) REFERENCES [tbl_CourseCategory]([CategoryId]),
CONSTRAINT UC_CourseTitle UNIQUE ([Title])
)

-------- END --------

IF OBJECT_ID (N'[tbl_CourseDetails]', N'U') IS NOT NULL 
   DROP TABLE [tbl_CourseDetails]

CREATE TABLE [tbl_CourseDetails]
(
[CDetailsId]	INT 			NOT NULL IDENTITY(1,1),
[CourseId]		INT				NOT NULL,
[Currency]		VARCHAR(300)	NOT NULL,
[Price]			Decimal(18,2)	NOT NULL,
[Ratting]		INT				NOT NULL,
[Duration]		INT				NOT NULL,
[NumOfClasses]	INT				NOT NULL,
[Image]			VARCHAR(MAX)	Not NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_CDetailsId PRIMARY KEY ([CDetailsId]),
CONSTRAINT FK_CDetailsCourseId FOREIGN KEY ([CourseId]) REFERENCES [tbl_Course]([CourseId]),
CONSTRAINT UC_CDCourseId UNIQUE ([CourseId])
)

-------- END --------

IF OBJECT_ID (N'[tbl_CourseContent]', N'U') IS NOT NULL 
   DROP TABLE [tbl_CourseContent]

CREATE TABLE [tbl_CourseContent]
(
[ContentId]		INT 			NOT NULL IDENTITY(1,1),
[CourseId]		INT				NOT NULL,
[Concepts]		VARCHAR(MAX)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_ContentId PRIMARY KEY ([ContentId]),
CONSTRAINT FK_ContentCourseId FOREIGN KEY ([CourseId]) REFERENCES [tbl_Course]([CourseId]),
CONSTRAINT UC_ContentChapter UNIQUE ([CourseId])
)

-------- END --------

IF OBJECT_ID (N'[tbl_Batches]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Batches]

CREATE TABLE [tbl_Batches]
(
[BatchId]		INT 			NOT NULL IDENTITY(1,1),
[BatchCode]		VARCHAR(30)		NOT NULL,
[CourseId]		INT				NOT NULL,
[StaffName]		VARCHAR(50)		NOT NULL,
[StartDate]		DATETIME		NOT NULL,
[BatchTime]		DATETIME		NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_BatchId PRIMARY KEY ([BatchId]),
CONSTRAINT FK_BatchCourseId FOREIGN KEY ([CourseId]) REFERENCES [tbl_Course]([CourseId]),
CONSTRAINT UC_ContentChapter UNIQUE ([BatchName])
)

-------- END --------

IF OBJECT_ID (N'[tbl_BatchStudents]', N'U') IS NOT NULL 
   DROP TABLE [tbl_BatchStudents]

CREATE TABLE [tbl_BatchStudents]
(
[BatchStudentId]	INT 		NOT NULL IDENTITY(1,1),
[BatchId]			INT			NOT NULL,
[StudentId]			INT			NOT NULL,
[CreatedDate]		DATETIME	DEFAULT GETDATE(),
CONSTRAINT PK_ContentId PRIMARY KEY ([BatchStudentId]),
CONSTRAINT FK_BSBatchId FOREIGN KEY ([BatchId]) REFERENCES [tbl_Batches]([BatchId]),
CONSTRAINT FK_BSStudetId FOREIGN KEY ([StudentId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT UC_BSBatchId UNIQUE ([BatchId])
)

-------- END --------