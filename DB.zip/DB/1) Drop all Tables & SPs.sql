USE Emprime_Dev

DROP TABLE [Ref_Roles]
DROP TABLE [tbl_Users]
DROP TABLE [Ref_Countries]
DROP TABLE [Ref_States]
DROP TABLE [tbl_UserMapping]
DROP TABLE [tbl_ResetPwdLog]
DROP TABLE [tbl_Menus]
DROP TABLE [tbl_SubMenus]
DROP TABLE [tbl_AssignMenus]
DROP PROCEDURE [USP_Get_AuthenticatedUser]