USE StepTek

IF OBJECT_ID (N'[Ref_Roles]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Roles]

CREATE TABLE [Ref_Roles]
(
[RoleId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE()
CONSTRAINT PK_RefRoleId PRIMARY KEY ([RoleId]),
CONSTRAINT UC_RefRoleCode UNIQUE ([Code])
)

INSERT [Ref_Roles] ([Code], [Description]) VALUES ('DEV', 'Developer')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('ADM', 'Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('STU', 'Student')

SELECT * FROM [Ref_Roles]  

----- END -----

IF OBJECT_ID (N'[tbl_Users]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Users]

CREATE TABLE [tbl_Users]
(
[UserId]				INT					NOT NULL IDENTITY(1,1),
[PersonalKey]			VARCHAR(800)		NOT NULL,
[FirstName]				VARCHAR(800)		NOT NULL,
[LastName]				VARCHAR(800)		NOT NULL,
[RoleId]				INT					NOT NULL,
[Password]				VARCHAR(800)		NOT NULL,
[SaltKey]				VARCHAR(800)		NOT NULL,
[Email]					VARCHAR(800)		NOT NULL,
[Mobile]				VARCHAR(800)		NOT NULL,
[Photo]					VARCHAR(MAX)		NULL,
[ImgType]				VARCHAR(800)		NULL,
[Gender]				VARCHAR(300)		NULL,
[IsFirstTimeLogin]		BIT					DEFAULT 1,
[IsActive]				BIT					DEFAULT 1,
[CreatedDate]			DATETIME			DEFAULT GETDATE()
CONSTRAINT PK_tblUserId PRIMARY KEY ([UserId]),
CONSTRAINT UC_UserEmail UNIQUE ([Email]),
CONSTRAINT UC_UserMobile UNIQUE ([Mobile])
)

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[Email],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedDate]) 
VALUES 
(
'2W6ppjh+6bi2veYXNrz3LyQVLFaj+r7/9CBL2horM8MhYF/kvm5kmSZ0t//tAStkHf0IWR8cPYE8kvPO7Qmc7w==',
'AhU+KNMJioCmoJw2oT+65g2UG+mIbJUYX2v0/BCMP6c=', 
'bF3touMtIMA9H+OOVGFlNctvgi6FTNaZmF6GVQU8aw8=', 
1,
'Nky5VhXfD6T9ZLaUWTO5BNeu+rMdVMz4X96RSeKh7mg=', 
'7SqpTsUktXWRoxWaEQFHHZBci/h7x4l2beOi2upTbls=', 
'GLlFWpU4PZsR+jb7S1PkGyvwFX9EHwCBLkie7NeA9o8=', 
'wWAOX1vUTy3SOlULE+99Bw==',
1,1,GETDATE()
)
---- Actual Values
--FirstName - ??
--LastName - ??
--Email - sampath.bandari51@gmail.com
--Mobile - ??
--Password - Step@123
--Salt - 1S4:q|F5

SELECT * FROM [tbl_Users]

----- END -----

IF OBJECT_ID (N'[Ref_Countries]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Countries]

CREATE TABLE [Ref_Countries]
(
[CountryId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_CountryId PRIMARY KEY ([CountryId]),
CONSTRAINT UC_CountryCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_Countries] ([Code], [Description]) VALUES ('GER', 'Germany')

SELECT * FROM [Ref_Countries]  

----- END -----

IF OBJECT_ID (N'[Ref_States]', N'U') IS NOT NULL 
   DROP TABLE [Ref_States]

CREATE TABLE [Ref_States]
(
[StateId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CountryId]		INT				NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_StateId PRIMARY KEY ([StateId]),
CONSTRAINT FK_CState FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_StateCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('HAM', 'Hamburg', 1)

SELECT * FROM [Ref_States]  

----- END -----

IF OBJECT_ID (N'[tbl_UserMapping]', N'U') IS NOT NULL 
   DROP TABLE [tbl_UserMapping]

CREATE TABLE [tbl_UserMapping]
(
[UserId]					INT				NOT NULL,
[IsPermanentAddress]		BIT				NULL,
[PermanentStreetAddress]	VARCHAR(MAX)	NULL,
[PermanentCity]				VARCHAR(800)	NULL,
[PermanentState]			INT				NULL,
[PermanentCountry]			INT				NULL,
[PermanentZipCode]			BIGINT			NULL,
[CurrentStreetAddress]		VARCHAR(MAX)	NULL,
[CurrentCity]				VARCHAR(800)	NULL,
[CurrentState]				INT				NULL,
[CurrentCountry]			INT				NULL,
[CurrentZipCode]			BIGINT			NULL,
CONSTRAINT FK_UMUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_UMPState FOREIGN KEY ([PermanentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMPCountry FOREIGN KEY ([PermanentCountry]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT FK_UMCState FOREIGN KEY ([CurrentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMCCountry FOREIGN KEY ([CurrentCountry]) REFERENCES [Ref_Countries]([CountryId])
)

SELECT * FROM [tbl_UserMapping]  

----- END -----

IF OBJECT_ID (N'[tbl_ResetPwdLog]', N'U') IS NOT NULL 
   DROP TABLE [tbl_ResetPwdLog]

CREATE TABLE [tbl_ResetPwdLog]
(
[ResetPwdLogId]		INT				NOT NULL IDENTITY(1,1),
[UserId]			INT				NOT NULL,
[GuidVal]			VARCHAR(800)	NOT NULL,
[IsReset]			BIT				NOT NULL,
[EntryDate]			DATETIME		NOT NULL
CONSTRAINT PK_ResetPwdLogId PRIMARY KEY ([ResetPwdLogId]),
CONSTRAINT FK_RPwdUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_ResetPwdLog]

----- END -----

IF OBJECT_ID (N'[tbl_Menus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Menus]

CREATE TABLE [tbl_Menus]
(
[ParentId]		INT				NOT NULL IDENTITY(1,1),
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NULL,
[Action]		VARCHAR(50)		NULL,
[HavingChild]	BIT				NOT NULL,
[Order]			INT				NOT NULL,
[Icon]			VARCHAR(50)		NOT NULL,
CONSTRAINT PK_ParentId PRIMARY KEY ([ParentId]),
CONSTRAINT UC_PHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelDev', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('All Users', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Master Data', NULL, NULL, 1, 3, 'fa fa-star-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Error Log', 'CPanelDev', 'ViewErrorLog', 0, 4, 'fa fa-exclamation-triangle')

SELECT * FROM [tbl_Menus]  

----- END -----

IF OBJECT_ID (N'[tbl_SubMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_SubMenus]

CREATE TABLE [tbl_SubMenus]
(
[ChildId]		INT 			NOT NULL IDENTITY(1,1),
[ParentId]		INT				NOT NULL,
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NOT NULL,
[Action]		VARCHAR(50)		NOT NULL,
[Order]			INT				NOT NULL,
CONSTRAINT PK_ChildId PRIMARY KEY ([ChildId]),
CONSTRAINT FK_SMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT UC_CHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Create', 'CPanelDev', 'CreateAllUsers', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Details', 'CPanelDev', 'AllUserDetails', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Roles', 'CPanelDev', 'CreateRole', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Menus', 'CPanelDev', 'CreateMenus', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Sub Menus', 'CPanelDev', 'CreateSubMenus', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Assigned Menus', 'CPanelDev', 'CreateAssignedMenus', 4)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Countries', 'CPanelDev', 'CreateCountries', 5)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'States', 'CPanelDev', 'CreateStates', 6)

SELECT * FROM [tbl_SubMenus]

----- END -----

IF OBJECT_ID (N'[tbl_AssignMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_AssignMenus]

CREATE TABLE [tbl_AssignMenus]
(
[AssignMenuId]	INT 	NOT NULL IDENTITY(1,1),
[ParentId]		INT		NOT NULL,
[RoleId]		INT		NOT NULL,
CONSTRAINT PK_AssignMenuId PRIMARY KEY ([AssignMenuId]),
CONSTRAINT FK_AMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT FK_AMenusRoleId FOREIGN KEY ([RoleId]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT UC_AMenusParentRole UNIQUE ([ParentId],[RoleId])
)

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (1, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (2, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (3, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (4, 1)

SELECT * FROM [tbl_AssignMenus]

----- END -----