USE StepTek

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [USP_Get_AuthenticatedUser]
( 
 @EmailId	VARCHAR(800),  
 @Password	VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	DECLARE @Status					VARCHAR(5),  
			@UserId					INT = NULL,  
			@FirstName				VARCHAR(800) = NULL,
			@LastName				VARCHAR(800) = NULL,
			@FullName				VARCHAR(800) = NULL,
			@Email					VARCHAR(800) = NULL,
			@Mobile					VARCHAR(800) = NULL,
			@RoleId					INT = NULL,  
			@RoleCode				VARCHAR(50) = NULL,  
			@IsFirstTimeLogin		BIT = NULL,
			@ProfilePic				VARCHAR(MAX) = NULL

	IF (SELECT Count(*) FROM [StepTekDB].[tbl_Users] WHERE Email = @EmailId AND @Password = @Password) = 0  
		BEGIN  
			SET @Status = 0   
		END  
	ELSE  
		BEGIN  
			SELECT  @Status = 1,  
					@UserId = U.UserId,  
					@FirstName = U.FirstName,  
					@LastName = U.LastName, 
					@FullName = (U.FirstName + ' ' + U.LastName),  
					@Email = U.Email,  
					@Mobile = U.Mobile,  
					@RoleId = U.RoleId,  
					@RoleCode = R.Code,  
					@ProfilePic = U.Photo,
					@IsFirstTimeLogin = U.IsFirstTimeLogin
			FROM   
				[StepTekDB].[tbl_Users] U
			INNER JOIN [StepTekDB].[Ref_Roles] R ON U.RoleId = R.RoleId
			WHERE U.Email = @EmailId  AND U.[Password] = @Password

			IF (SELECT Count(*) FROM [StepTekDB].[tbl_UserMapping] WHERE UserId = @UserId) = 0  
				BEGIN
					INSERT INTO [StepTekDB].[tbl_UserMapping] (UserId) VALUES (@UserId)
				END
	  END  


	SELECT  @Status AS [Status],
			@UserId AS UserId,
			@FirstName AS FirstName,
			@LastName AS LastName,
			@FullName AS FullName,
			@Email AS Email,
			@Mobile AS Mobile,
			@RoleId AS RoleId, 
			@RoleCode AS RoleCode,
			@ProfilePic AS Photo,
			@IsFirstTimeLogin AS IsFirstTimeLogin
END 
--EXEC USP_Get_AuthenticatedUser 'GLlFWpU4PZsR+jb7S1PkGyvwFX9EHwCBLkie7NeA9o8=','Nky5VhXfD6T9ZLaUWTO5BNeu+rMdVMz4X96RSeKh7mg='
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_Get_MenuListByRole]
(
	@RoleCode	VARCHAR(10)
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RoleId INT
	SET @RoleId= (SELECT RoleId FROM [StepTekDB].[Ref_Roles] WHERE Code = @RoleCode)

	SELECT
		AM.ParentId,
		M.Header,
		M.Controller,
		M.[Action],
		M.HavingChild,
		M.[Order],
		M.Icon
	FROM [StepTekDB].[tbl_AssignMenus] AS AM
	INNER JOIN [StepTekDB].[tbl_Menus] M ON M.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId
	
	SELECT
		AM.ParentId,
		SM.Header,
		SM.Controller,
		SM.[Action],
		SM.[Order]
	FROM [StepTekDB].[tbl_AssignMenus] AS AM
	INNER JOIN [StepTekDB].[tbl_SubMenus] SM ON SM.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId	

END
-- EXEC USP_Get_MenuListByRole 132,4